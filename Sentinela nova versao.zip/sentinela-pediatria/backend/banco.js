/* =====================================================
   banco.js — leitura e gravação do arquivo db.json
   + funções de senha (hash com sal).
   ===================================================== */

const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

/* ---------- Onde o banco fica salvo ---------- */

let ARQUIVO = path.join(__dirname, "db.json");

// Na Vercel só podemos escrever em /tmp (disco temporário).
// Atenção: lá os dados são apagados de tempos em tempos.
if (process.env.VERCEL) {
  const temporario = "/tmp/db.json";
  if (!fs.existsSync(temporario)) {
    fs.copyFileSync(ARQUIVO, temporario);
  }
  ARQUIVO = temporario;
}

/* ---------- Listas que sempre precisam existir no banco ---------- */

const COLECOES = [
  // sistema hospitalar
  "usuarios",
  "pacientes",
  "triagens",
  "consultas",
  "chamadas",
  "estoque",
  "entradas",
  "altas",
  // cuidado emocional e bem-estar
  "encaminhamentos",
  "sessoesPsicologia",
  "avaliacoesPsiquiatria",
  "humores",
  "participacoes",
  // acolhimento infantil, desenvolvimento e família
  "sessoesSensorial",
  "registrosPedagogicos",
  "avaliacoesDesenvolvimento",
  "apoioFamiliar",
  "programacao",
  "presencas",
  // enfermagem
  "cuidadosEnfermagem",
  // administração e comunicação
  "profissionais",
  "setores",
  "salas",
  "reservas",
  "avisos",
  // Sentinela Intelligence
  "auditoria"
];

/* ---------- Dados iniciais (só entram se a lista estiver vazia) ---------- */

const SETORES_INICIAIS = [
  ["Recepção", "assistencial"], ["Triagem", "assistencial"], ["Pediatria", "assistencial"],
  ["Enfermagem", "assistencial"], ["Psicologia infantil", "assistencial"],
  ["Psiquiatria infantil", "assistencial"], ["Brinquedoteca e recreação", "infantil"],
  ["Espaço sensorial e acolhimento", "infantil"], ["Pedagogia hospitalar", "infantil"],
  ["Farmácia e almoxarifado", "apoio"], ["Administração", "administrativo"]
];

const SALAS_INICIAIS = [
  ["Brinquedoteca", "brinquedoteca", 12], ["Sala de recreação", "recreacao", 15],
  ["Espaço sensorial", "sensorial", 4], ["Área de convivência infantil", "convivencia", 20],
  ["Sala de pedagogia hospitalar", "pedagogia", 8],
  ["Consultório de psicologia infantil", "psicologia", 3],
  ["Consultório de psiquiatria infantil", "psiquiatria", 3],
  ["Consultório pediátrico", "consultorio", 3], ["Sala de triagem", "triagem", 3]
];

function semear(dados) {
  let mudou = false;
  let proximoId = Date.now();

  if (!dados.setores.length) {
    SETORES_INICIAIS.forEach(([nome, tipo]) => {
      dados.setores.push({ id: proximoId++, nome, tipo, responsavel: "", descricao: "", ativo: true });
    });
    mudou = true;
  }

  if (!dados.salas.length) {
    SALAS_INICIAIS.forEach(([nome, tipo, capacidade]) => {
      dados.salas.push({
        id: proximoId++, nome, tipo, capacidade, status: "ativa",
        responsavel: "", descricao: "", setorId: null
      });
    });
    mudou = true;
  }

  return mudou;
}

/* ---------- Senhas ---------- */

// Transforma "123" em "sal:hash" (nunca guardamos a senha pura).
function gerarHash(senha) {
  const sal = crypto.randomBytes(8).toString("hex");
  const chave = crypto.scryptSync(senha, sal, 32).toString("hex");
  return sal + ":" + chave;
}

// Confere se a senha digitada corresponde ao que está guardado.
function conferirSenha(senha, guardada) {
  // Compatibilidade: senha antiga ainda em texto puro.
  if (!guardada.includes(":")) {
    return senha === guardada;
  }

  const [sal, chave] = guardada.split(":");
  const calculada = crypto.scryptSync(senha, sal, 32);
  return crypto.timingSafeEqual(calculada, Buffer.from(chave, "hex"));
}

/* ---------- Leitura e gravação ---------- */

function gravar(dados) {
  fs.writeFileSync(ARQUIVO, JSON.stringify(dados, null, 2));
}

function ler() {
  const dados = JSON.parse(fs.readFileSync(ARQUIVO, "utf8"));
  let precisaGravar = false;

  // Área de configuração do sistema (ex.: chave que assina as sessões).
  if (!dados.config || typeof dados.config !== "object") {
    dados.config = {};
  }

  // Garante que toda lista exista (bancos antigos não tinham as novas).
  for (const nome of COLECOES) {
    if (!Array.isArray(dados[nome])) {
      dados[nome] = [];
    }
  }

  // Setores e salas padrão para bancos que ainda não os têm.
  if (semear(dados)) {
    precisaGravar = true;
  }

  // Senhas antigas em texto puro viram hash automaticamente.
  for (const usuario of dados.usuarios) {
    if (!usuario.senha.includes(":")) {
      usuario.senha = gerarHash(usuario.senha);
      precisaGravar = true;
    }
  }

  if (precisaGravar) {
    gravar(dados);
  }

  return dados;
}

module.exports = { ler, gravar, gerarHash, conferirSenha };
