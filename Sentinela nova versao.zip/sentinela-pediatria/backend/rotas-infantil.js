/* =====================================================
   rotas-infantil.js — acolhimento e desenvolvimento infantil:
     • espaço sensorial (sessões)
     • pedagogia hospitalar (atividades escolares)
     • acompanhamento do desenvolvimento
     • programação de atividades infantis (com inscrição)
   ===================================================== */

const express = require("express");

const Bem = require("../frontend/js/bemestar.js");
const Hosp = require("../frontend/js/hospital.js");
const { ler, gravar } = require("./banco");
const { txt, bad, rota, novoId, inteiroEntre } = require("./util");
const {
  buscarPaciente, criarEncaminhamento, concluirEncaminhamentos, ultimos,
  hojeISO, dataValida, horaValida, minutos, conflitoReserva
} = require("./apoio");

const router = express.Router();

const existe = (lista, id) => lista.some(item => item.id === id);

// Filtro simples por criança (?pacienteId=).
const daCrianca = req => item => !req.query.pacienteId || item.pacienteId === Number(req.query.pacienteId);

/* =====================================================
   ESPAÇO SENSORIAL
   ===================================================== */
router.post("/sensorial/sessao", rota((req, res) => {
  const b = req.body;
  const dados = ler();

  const paciente = buscarPaciente(dados, b.pacienteId);
  if (!paciente) return bad(res, "Selecione a criança.", 404);

  const estimulos = (Array.isArray(b.estimulos) ? b.estimulos : []).filter(id => existe(Hosp.ESTIMULOS_SENSORIAIS, id));
  if (!estimulos.length) return bad(res, "Escolha ao menos um estímulo usado na sessão.");

  if (!b.liberado) return bad(res, "Confirme que a equipe de saúde liberou a criança para o espaço sensorial.");
  if (!existe(Hosp.TOLERANCIA_SENSORIAL, txt(b.tolerancia))) return bad(res, "Informe como a criança reagiu.");

  const humorAntes = inteiroEntre(b.humorAntes, 1, 5);
  const humorDepois = inteiroEntre(b.humorDepois, 1, 5);
  const duracao = inteiroEntre(b.duracao, 1, 240);
  if (humorAntes === undefined || humorDepois === undefined) return bad(res, "Humor inválido.");
  if (duracao === undefined) return bad(res, "Duração inválida (1 a 240 minutos).");

  const profissional = txt(b.profissional);
  if (!profissional) return bad(res, "Informe o profissional responsável.");

  const sala = b.salaId ? dados.salas.find(s => s.id === Number(b.salaId)) : null;

  const sessao = {
    id: novoId(),
    pacienteId: paciente.id,
    paciente: paciente.nome,
    salaId: sala ? sala.id : null,
    sala: sala ? sala.nome : "",
    estimulos,
    tolerancia: txt(b.tolerancia),
    duracao,
    humorAntes,
    humorDepois,
    observacao: txt(b.observacao),
    profissional,
    registro: txt(b.registro),
    createdAt: new Date().toISOString()
  };
  dados.sessoesSensorial.push(sessao);
  concluirEncaminhamentos(dados, paciente.id, "bemestar");
  gravar(dados);

  res.status(201).json(sessao);
}));

router.get("/sensorial/sessoes", rota((req, res) => {
  res.json(ultimos(ler().sessoesSensorial.filter(daCrianca(req)), req.query.limite, 20));
}));

/* =====================================================
   PEDAGOGIA HOSPITALAR
   ===================================================== */
router.post("/pedagogia/registro", rota((req, res) => {
  const b = req.body;
  const dados = ler();

  const paciente = buscarPaciente(dados, b.pacienteId);
  if (!paciente) return bad(res, "Selecione a criança.", 404);

  const tipo = txt(b.tipo);
  if (!existe(Hosp.TIPOS_PEDAGOGIA, tipo)) return bad(res, "Selecione o tipo de registro.");

  const atividade = txt(b.atividade);
  if (!atividade) return bad(res, "Descreva a atividade ou o acompanhamento realizado.");

  const duracao = inteiroEntre(b.duracao, 1, 480);
  const engajamento = inteiroEntre(b.engajamento, 1, 5);
  if (duracao === undefined) return bad(res, "Duração inválida (1 a 480 minutos).");
  if (engajamento === undefined) return bad(res, "Participação inválida (1 a 5).");

  const profissional = txt(b.profissional);
  if (!profissional) return bad(res, "Informe o profissional responsável.");

  const registro = {
    id: novoId(),
    pacienteId: paciente.id,
    paciente: paciente.nome,
    tipo,
    escola: txt(b.escola),
    serie: txt(b.serie),
    disciplina: txt(b.disciplina),
    atividade,
    duracao,
    engajamento,
    observacao: txt(b.observacao),
    profissional,
    registro: txt(b.registro),
    createdAt: new Date().toISOString()
  };
  dados.registrosPedagogicos.push(registro);
  concluirEncaminhamentos(dados, paciente.id, "pedagogia");
  gravar(dados);

  res.status(201).json(registro);
}));

router.get("/pedagogia/registros", rota((req, res) => {
  res.json(ultimos(ler().registrosPedagogicos.filter(daCrianca(req)), req.query.limite, 20));
}));

// Escola e série mais recentes da criança (para preencher o formulário).
router.get("/pedagogia/perfil/:id", rota((req, res) => {
  const registros = ler().registrosPedagogicos.filter(r => r.pacienteId === Number(req.params.id));
  const ultimaEscola = registros.slice().reverse().find(r => r.escola || r.serie) || {};
  res.json({ escola: ultimaEscola.escola || "", serie: ultimaEscola.serie || "", total: registros.length });
}));

/* =====================================================
   ACOMPANHAMENTO DO DESENVOLVIMENTO
   ===================================================== */
router.post("/desenvolvimento/avaliacao", rota((req, res) => {
  const b = req.body;
  const dados = ler();

  const paciente = buscarPaciente(dados, b.pacienteId);
  if (!paciente) return bad(res, "Selecione a criança.", 404);

  const areas = {};
  for (const area of Hosp.AREAS_DESENVOLVIMENTO) {
    const nota = inteiroEntre((b.areas || {})[area.id], 1, 4);
    if (nota === undefined) return bad(res, "Nota inválida em: " + area.nome);
    if (nota !== null) areas[area.id] = nota;
  }
  if (!Object.keys(areas).length) return bad(res, "Avalie ao menos uma área do desenvolvimento.");

  const profissional = txt(b.profissional);
  if (!profissional) return bad(res, "Informe o profissional responsável.");

  const destinos = (Array.isArray(b.encaminhar) ? b.encaminhar : []).filter(d => Bem.DESTINOS.includes(d));
  const atencao = Object.keys(areas).filter(id => areas[id] <= 2);

  const avaliacao = {
    id: novoId(),
    pacienteId: paciente.id,
    paciente: paciente.nome,
    areas,
    atencao,
    marcos: txt(b.marcos),
    recomendacoes: txt(b.recomendacoes),
    encaminhou: destinos,
    profissional,
    registro: txt(b.registro),
    createdAt: new Date().toISOString()
  };
  dados.avaliacoesDesenvolvimento.push(avaliacao);

  destinos.forEach(destino => criarEncaminhamento(
    dados, paciente, destino,
    "Acompanhamento do desenvolvimento: atenção em " +
      (atencao.map(id => Hosp.nomeDe(Hosp.AREAS_DESENVOLVIMENTO, id).split(" (")[0]).join(", ") || "avaliação geral") + ".",
    "rotina", "desenvolvimento"
  ));

  gravar(dados);
  res.status(201).json(avaliacao);
}));

// Com ?pacienteId= devolve do mais antigo ao mais novo (para o gráfico).
router.get("/desenvolvimento/avaliacoes", rota((req, res) => {
  const lista = ler().avaliacoesDesenvolvimento.filter(daCrianca(req));
  res.json(req.query.pacienteId ? lista.slice(-50) : ultimos(lista, req.query.limite, 20));
}));

/* =====================================================
   PROGRAMAÇÃO DE ATIVIDADES INFANTIS
   Cada atividade ocupa uma sala (cria uma reserva) e
   tem vagas para as crianças inscritas.
   ===================================================== */

function apresentarProgramacao(dados, p) {
  const sala = dados.salas.find(s => s.id === p.salaId);
  const atividade = Bem.ATIVIDADES.find(a => a.id === p.atividadeId);

  return {
    ...p,
    sala: sala ? sala.nome : "(sala removida)",
    atividade: atividade ? atividade.nome : p.atividadeId,
    icone: atividade ? atividade.icone : "🎈",
    categoria: atividade ? atividade.categoria : "",
    vagasLivres: Math.max(0, p.vagas - p.inscritos.length)
  };
}

router.post("/programacao", rota((req, res) => {
  const b = req.body;
  const dados = ler();

  const atividade = Bem.ATIVIDADES.find(a => a.id === txt(b.atividadeId));
  if (!atividade) return bad(res, "Escolha a atividade.");

  const sala = dados.salas.find(s => s.id === Number(b.salaId));
  if (!sala) return bad(res, "Escolha a sala.");
  if (sala.status !== "ativa") return bad(res, "Esta sala não está em funcionamento.", 409);

  const data = txt(b.data), inicio = txt(b.inicio), fim = txt(b.fim);
  if (!dataValida(data)) return bad(res, "Data inválida.");
  if (!horaValida(inicio) || !horaValida(fim)) return bad(res, "Informe horário de início e de fim.");
  if (minutos(fim) <= minutos(inicio)) return bad(res, "O fim deve ser depois do início.");

  const vagas = inteiroEntre(b.vagas, 1, sala.capacidade || 100);
  if (vagas === null || vagas === undefined) return bad(res, "Vagas inválidas (máximo: a capacidade da sala, " + sala.capacidade + ").");

  const responsavel = txt(b.responsavel);
  if (!responsavel) return bad(res, "Informe o profissional ou voluntário responsável.");

  const choque = conflitoReserva(dados, sala.id, data, inicio, fim);
  if (choque) return bad(res, `A sala já está reservada das ${choque.inicio} às ${choque.fim} (${choque.titulo}).`, 409);

  const id = novoId();
  dados.reservas.push({
    id: novoId(), salaId: sala.id, data, inicio, fim, status: "ativa",
    titulo: txt(b.titulo) || atividade.nome, responsavel, programacaoId: id,
    createdAt: new Date().toISOString()
  });

  const programacao = {
    id,
    titulo: txt(b.titulo) || atividade.nome,
    atividadeId: atividade.id,
    salaId: sala.id,
    data, inicio, fim, vagas,
    faixaEtaria: txt(b.faixaEtaria),
    descricao: txt(b.descricao),
    responsavel,
    inscritos: [],
    status: "agendada",
    createdAt: new Date().toISOString()
  };
  dados.programacao.push(programacao);
  gravar(dados);

  res.status(201).json(apresentarProgramacao(dados, programacao));
}));

router.get("/programacao", rota((req, res) => {
  const dados = ler();
  const { data, de, ate } = req.query;

  const lista = dados.programacao
    .filter(p => !data || p.data === data)
    .filter(p => !de || p.data >= de)
    .filter(p => !ate || p.data <= ate)
    .sort((a, b) => (a.data + a.inicio).localeCompare(b.data + b.inicio))
    .map(p => apresentarProgramacao(dados, p));

  res.json(lista);
}));

router.post("/programacao/:id/inscrever", rota((req, res) => {
  const dados = ler();
  const p = dados.programacao.find(x => x.id === Number(req.params.id));
  if (!p) return bad(res, "Atividade não encontrada.", 404);
  if (p.status !== "agendada") return bad(res, "Esta atividade já foi encerrada.", 409);

  const paciente = buscarPaciente(dados, req.body.pacienteId);
  if (!paciente) return bad(res, "Selecione a criança.", 404);
  if (paciente.status === "encerrado") return bad(res, "Esta criança já recebeu alta.", 409);

  if (p.inscritos.some(i => i.pacienteId === paciente.id)) return bad(res, "A criança já está inscrita.", 409);
  if (p.inscritos.length >= p.vagas) return bad(res, "Não há mais vagas nesta atividade.", 409);

  p.inscritos.push({ pacienteId: paciente.id, nome: paciente.nome });
  gravar(dados);
  res.status(201).json(apresentarProgramacao(dados, p));
}));

router.delete("/programacao/:id/inscritos/:pacienteId", rota((req, res) => {
  const dados = ler();
  const p = dados.programacao.find(x => x.id === Number(req.params.id));
  if (!p) return bad(res, "Atividade não encontrada.", 404);
  if (p.status !== "agendada") return bad(res, "Esta atividade já foi encerrada.", 409);

  p.inscritos = p.inscritos.filter(i => i.pacienteId !== Number(req.params.pacienteId));
  gravar(dados);
  res.json(apresentarProgramacao(dados, p));
}));

// Encerra: "realizada" (gera a participação de cada criança) ou "cancelada" (libera a sala).
router.put("/programacao/:id", rota((req, res) => {
  const dados = ler();
  const p = dados.programacao.find(x => x.id === Number(req.params.id));
  if (!p) return bad(res, "Atividade não encontrada.", 404);

  const status = txt(req.body.status);
  if (!["realizada", "cancelada"].includes(status)) return bad(res, "Status inválido.");
  if (p.status !== "agendada") return bad(res, "Esta atividade já foi encerrada.", 409);

  p.status = status;

  const reserva = dados.reservas.find(r => r.programacaoId === p.id);
  if (reserva && status === "cancelada") reserva.status = "cancelada";

  if (status === "realizada") {
    const atividade = Bem.ATIVIDADES.find(a => a.id === p.atividadeId);
    p.inscritos.forEach(inscrito => {
      dados.participacoes.push({
        id: novoId(),
        pacienteId: inscrito.pacienteId,
        paciente: inscrito.nome,
        atividadeId: p.atividadeId,
        atividade: atividade ? atividade.nome : p.titulo,
        icone: atividade ? atividade.icone : "🎈",
        data: p.data,
        horario: p.inicio,
        observacao: "Atividade em grupo: " + p.titulo,
        profissional: p.responsavel,
        status: "realizada",
        reacao: null,
        origem: "programacao",
        programacaoId: p.id,
        createdAt: new Date().toISOString()
      });
      concluirEncaminhamentos(dados, inscrito.pacienteId, "bemestar");
    });
  }

  gravar(dados);
  res.json(apresentarProgramacao(dados, p));
}));

module.exports = router;
