/* =====================================================
   rotas-gestao.js — administração e comunicação:
     • profissionais e setores
     • salas, presença das crianças e reservas
     • avisos (mural interno e painel da TV)
     • controle de atividades e relatórios
     • contadores do menu lateral
   ===================================================== */

const express = require("express");

const Hosp = require("../frontend/js/hospital.js");
const { ler, gravar } = require("./banco");
const { txt, bad, rota, novoId, inteiroEntre } = require("./util");
const { exigirTipo } = require("./auth");
const { buscarPaciente, hojeISO, dataValida, horaValida, minutos, conflitoReserva } = require("./apoio");
const { alertasGerais } = require("./ia/paciente");
const { pode } = require("./ia/permissoes");

const router = express.Router();
const soAdmin = exigirTipo("admin");
const existe = (lista, id) => lista.some(item => item.id === id);

/* =====================================================
   PROFISSIONAIS
   ===================================================== */
const pessoa = p => ({ id: p.id, nome: p.nome, categoria: p.categoria, conselho: p.conselho,
  registro: p.registro, especialidade: p.especialidade, setorId: p.setorId, status: p.status });

router.get("/profissionais", rota((req, res) => {
  const completo = req.sessao.tipo === "admin";
  const lista = ler().profissionais
    .filter(p => !req.query.ativos || p.status === "ativo")
    .map(p => completo ? p : pessoa(p))
    .sort((a, b) => a.nome.localeCompare(b.nome, "pt-BR"));
  res.json(lista);
}));

function lerProfissional(b, dados, idAtual) {
  const nome = txt(b.nome);
  if (!nome) return { erro: "Informe o nome do profissional." };

  const categoria = Hosp.porId(Hosp.CATEGORIAS_PROFISSIONAL, txt(b.categoria));
  if (!categoria) return { erro: "Selecione a categoria profissional." };

  const status = txt(b.status) || "ativo";
  if (!existe(Hosp.STATUS_PROFISSIONAL, status)) return { erro: "Situação inválida." };

  const conselho = txt(b.conselho) || categoria.conselho;
  const registro = txt(b.registro);
  if (conselho && !registro) return { erro: `Informe o número do registro (${conselho}).` };

  if (registro && dados.profissionais.some(p =>
    p.id !== idAtual && p.registro === registro && (p.conselho || "") === conselho)) {
    return { erro: `Já existe profissional com o registro ${conselho} ${registro}.` };
  }

  const setorId = b.setorId ? Number(b.setorId) : null;
  if (setorId && !dados.setores.some(s => s.id === setorId)) return { erro: "Setor não encontrado." };

  const usuario = txt(b.usuario);
  if (usuario && !dados.usuarios.some(u => u.usuario === usuario)) return { erro: "O usuário de login informado não existe." };

  return {
    valores: {
      nome, categoria: categoria.id, conselho, registro, status, setorId, usuario,
      especialidade: txt(b.especialidade), turno: txt(b.turno),
      telefone: txt(b.telefone), email: txt(b.email)
    }
  };
}

router.post("/profissionais", soAdmin, rota((req, res) => {
  const dados = ler();
  const { valores, erro } = lerProfissional(req.body, dados, null);
  if (erro) return bad(res, erro);

  const profissional = { id: novoId(), ...valores, createdAt: new Date().toISOString() };
  dados.profissionais.push(profissional);
  gravar(dados);
  res.status(201).json(profissional);
}));

router.put("/profissionais/:id", soAdmin, rota((req, res) => {
  const dados = ler();
  const profissional = dados.profissionais.find(p => p.id === Number(req.params.id));
  if (!profissional) return bad(res, "Profissional não encontrado.", 404);

  const { valores, erro } = lerProfissional(req.body, dados, profissional.id);
  if (erro) return bad(res, erro);

  Object.assign(profissional, valores);
  gravar(dados);
  res.json(profissional);
}));

router.delete("/profissionais/:id", soAdmin, rota((req, res) => {
  const dados = ler();
  const indice = dados.profissionais.findIndex(p => p.id === Number(req.params.id));
  if (indice < 0) return bad(res, "Profissional não encontrado.", 404);

  dados.profissionais.splice(indice, 1);
  gravar(dados);
  res.json({ mensagem: "Profissional excluído." });
}));

/* =====================================================
   SETORES
   ===================================================== */
router.get("/setores", rota((req, res) => {
  const dados = ler();
  res.json(dados.setores.map(s => ({
    ...s,
    salas: dados.salas.filter(sala => sala.setorId === s.id).length,
    profissionais: dados.profissionais.filter(p => p.setorId === s.id && p.status === "ativo").length
  })));
}));

function lerSetor(b, dados, idAtual) {
  const nome = txt(b.nome);
  if (!nome) return { erro: "Informe o nome do setor." };
  if (!existe(Hosp.TIPOS_SETOR, txt(b.tipo))) return { erro: "Selecione o tipo do setor." };
  if (dados.setores.some(s => s.id !== idAtual && s.nome.toLowerCase() === nome.toLowerCase())) {
    return { erro: "Já existe um setor com esse nome." };
  }
  return { valores: { nome, tipo: txt(b.tipo), responsavel: txt(b.responsavel), descricao: txt(b.descricao), ativo: b.ativo !== false } };
}

router.post("/setores", soAdmin, rota((req, res) => {
  const dados = ler();
  const { valores, erro } = lerSetor(req.body, dados, null);
  if (erro) return bad(res, erro);

  const setor = { id: novoId(), ...valores };
  dados.setores.push(setor);
  gravar(dados);
  res.status(201).json(setor);
}));

router.put("/setores/:id", soAdmin, rota((req, res) => {
  const dados = ler();
  const setor = dados.setores.find(s => s.id === Number(req.params.id));
  if (!setor) return bad(res, "Setor não encontrado.", 404);

  const { valores, erro } = lerSetor(req.body, dados, setor.id);
  if (erro) return bad(res, erro);

  Object.assign(setor, valores);
  gravar(dados);
  res.json(setor);
}));

router.delete("/setores/:id", soAdmin, rota((req, res) => {
  const dados = ler();
  const id = Number(req.params.id);
  const indice = dados.setores.findIndex(s => s.id === id);
  if (indice < 0) return bad(res, "Setor não encontrado.", 404);

  if (dados.salas.some(s => s.setorId === id) || dados.profissionais.some(p => p.setorId === id)) {
    return bad(res, "Há salas ou profissionais neste setor. Mude-os de setor (ou desative o setor) antes de excluir.", 409);
  }
  dados.setores.splice(indice, 1);
  gravar(dados);
  res.json({ mensagem: "Setor excluído." });
}));

/* =====================================================
   SALAS, PRESENÇA E RESERVAS
   ===================================================== */
function apresentarSala(dados, sala, agora = new Date()) {
  const hoje = agora.toISOString().slice(0, 10);
  const hora = ("0" + agora.getHours()).slice(-2) + ":" + ("0" + agora.getMinutes()).slice(-2);

  const presentes = dados.presencas.filter(p => p.salaId === sala.id && !p.saiuEm);
  const reservasHoje = dados.reservas
    .filter(r => r.salaId === sala.id && r.status === "ativa" && r.data === hoje)
    .sort((a, b) => a.inicio.localeCompare(b.inicio));
  const reservaAgora = reservasHoje.find(r => r.inicio <= hora && hora < r.fim) || null;

  let situacao = "livre";
  if (sala.status !== "ativa") situacao = sala.status;
  else if (presentes.length >= sala.capacidade) situacao = "lotada";
  else if (presentes.length) situacao = "em-uso";
  else if (reservaAgora) situacao = "reservada";

  return { ...sala, situacao, presentes: presentes.length, presentesLista: presentes, reservaAgora, reservasHoje };
}

router.get("/salas", rota((req, res) => {
  const dados = ler();
  const agora = new Date(req.query.agora || Date.now());
  const lista = dados.salas
    .filter(s => !req.query.tipo || s.tipo === req.query.tipo)
    .filter(s => !req.query.acolhimento || (Hosp.porId(Hosp.TIPOS_SALA, s.tipo) || {}).acolhimento)
    .map(s => apresentarSala(dados, s, isNaN(agora) ? new Date() : agora));
  res.json(lista);
}));

function lerSala(b, dados, idAtual) {
  const nome = txt(b.nome);
  if (!nome) return { erro: "Informe o nome da sala." };
  if (!existe(Hosp.TIPOS_SALA, txt(b.tipo))) return { erro: "Selecione o tipo da sala." };

  const capacidade = inteiroEntre(b.capacidade, 1, 500);
  if (!capacidade) return { erro: "Informe a capacidade (1 a 500 pessoas)." };

  const status = txt(b.status) || "ativa";
  if (!existe(Hosp.STATUS_SALA, status)) return { erro: "Situação inválida." };

  if (dados.salas.some(s => s.id !== idAtual && s.nome.toLowerCase() === nome.toLowerCase())) {
    return { erro: "Já existe uma sala com esse nome." };
  }
  const setorId = b.setorId ? Number(b.setorId) : null;
  if (setorId && !dados.setores.some(s => s.id === setorId)) return { erro: "Setor não encontrado." };

  return { valores: { nome, tipo: txt(b.tipo), capacidade, status, setorId, responsavel: txt(b.responsavel), descricao: txt(b.descricao) } };
}

router.post("/salas", soAdmin, rota((req, res) => {
  const dados = ler();
  const { valores, erro } = lerSala(req.body, dados, null);
  if (erro) return bad(res, erro);

  const sala = { id: novoId(), ...valores };
  dados.salas.push(sala);
  gravar(dados);
  res.status(201).json(sala);
}));

router.put("/salas/:id", soAdmin, rota((req, res) => {
  const dados = ler();
  const sala = dados.salas.find(s => s.id === Number(req.params.id));
  if (!sala) return bad(res, "Sala não encontrada.", 404);

  const { valores, erro } = lerSala(req.body, dados, sala.id);
  if (erro) return bad(res, erro);

  Object.assign(sala, valores);
  gravar(dados);
  res.json(sala);
}));

router.delete("/salas/:id", soAdmin, rota((req, res) => {
  const dados = ler();
  const id = Number(req.params.id);
  const indice = dados.salas.findIndex(s => s.id === id);
  if (indice < 0) return bad(res, "Sala não encontrada.", 404);

  if (dados.presencas.some(p => p.salaId === id && !p.saiuEm)) return bad(res, "Há crianças na sala agora.", 409);
  if (dados.reservas.some(r => r.salaId === id && r.status === "ativa" && r.data >= hojeISO())) {
    return bad(res, "Há reservas futuras nesta sala. Cancele-as antes de excluir.", 409);
  }
  dados.salas.splice(indice, 1);
  gravar(dados);
  res.json({ mensagem: "Sala excluída." });
}));

/* ---------- Presença das crianças nos espaços ---------- */
router.post("/salas/:id/entrada", rota((req, res) => {
  const dados = ler();
  const sala = dados.salas.find(s => s.id === Number(req.params.id));
  if (!sala) return bad(res, "Sala não encontrada.", 404);
  if (sala.status !== "ativa") return bad(res, "Esta sala não está em funcionamento.", 409);

  const paciente = buscarPaciente(dados, req.body.pacienteId);
  if (!paciente) return bad(res, "Selecione a criança.", 404);
  if (paciente.status === "encerrado") return bad(res, "Esta criança já recebeu alta.", 409);

  const emOutra = dados.presencas.find(p => p.pacienteId === paciente.id && !p.saiuEm);
  if (emOutra) return bad(res, `${paciente.nome} já está em: ${emOutra.sala}. Registre a saída antes.`, 409);

  const dentro = dados.presencas.filter(p => p.salaId === sala.id && !p.saiuEm).length;
  if (dentro >= sala.capacidade) return bad(res, "A sala está na capacidade máxima.", 409);

  const presenca = {
    id: novoId(), salaId: sala.id, sala: sala.nome, pacienteId: paciente.id, paciente: paciente.nome,
    acompanhante: txt(req.body.acompanhante), operador: req.sessao.usuario,
    entrouEm: new Date().toISOString(), saiuEm: null
  };
  dados.presencas.push(presenca);
  gravar(dados);
  res.status(201).json(presenca);
}));

router.post("/salas/:id/saida", rota((req, res) => {
  const dados = ler();
  const presenca = dados.presencas.find(p =>
    p.salaId === Number(req.params.id) && p.pacienteId === Number(req.body.pacienteId) && !p.saiuEm);
  if (!presenca) return bad(res, "Esta criança não está na sala.", 404);

  presenca.saiuEm = new Date().toISOString();
  gravar(dados);
  res.json(presenca);
}));

/* ---------- Reservas ---------- */
router.get("/reservas", rota((req, res) => {
  const { data, salaId } = req.query;
  const dados = ler();
  const lista = dados.reservas
    .filter(r => r.status === "ativa")
    .filter(r => !data || r.data === data)
    .filter(r => !salaId || r.salaId === Number(salaId))
    .sort((a, b) => (a.data + a.inicio).localeCompare(b.data + b.inicio))
    .map(r => ({ ...r, sala: (dados.salas.find(s => s.id === r.salaId) || {}).nome || "(sala removida)" }));
  res.json(lista);
}));

router.post("/reservas", exigirTipo("admin", "bemestar", "pedagogia", "psicologia", "psiquiatria", "atendimento"), rota((req, res) => {
  const b = req.body;
  const dados = ler();

  const sala = dados.salas.find(s => s.id === Number(b.salaId));
  if (!sala) return bad(res, "Escolha a sala.", 404);
  if (sala.status !== "ativa") return bad(res, "Esta sala não está em funcionamento.", 409);

  const data = txt(b.data), inicio = txt(b.inicio), fim = txt(b.fim);
  if (!dataValida(data)) return bad(res, "Data inválida.");
  if (!horaValida(inicio) || !horaValida(fim)) return bad(res, "Informe horário de início e de fim.");
  if (minutos(fim) <= minutos(inicio)) return bad(res, "O fim deve ser depois do início.");

  const titulo = txt(b.titulo);
  if (!titulo) return bad(res, "Informe para que a sala será usada.");

  const choque = conflitoReserva(dados, sala.id, data, inicio, fim);
  if (choque) return bad(res, `A sala já está reservada das ${choque.inicio} às ${choque.fim} (${choque.titulo}).`, 409);

  const reserva = {
    id: novoId(), salaId: sala.id, data, inicio, fim, titulo,
    responsavel: txt(b.responsavel) || req.sessao.usuario, status: "ativa",
    createdAt: new Date().toISOString()
  };
  dados.reservas.push(reserva);
  gravar(dados);
  res.status(201).json(reserva);
}));

router.delete("/reservas/:id", rota((req, res) => {
  const dados = ler();
  const reserva = dados.reservas.find(r => r.id === Number(req.params.id));
  if (!reserva || reserva.status !== "ativa") return bad(res, "Reserva não encontrada.", 404);
  if (reserva.programacaoId) return bad(res, "Esta reserva pertence a uma atividade da programação. Cancele pela programação.", 409);

  reserva.status = "cancelada";
  gravar(dados);
  res.json({ mensagem: "Reserva cancelada." });
}));

/* =====================================================
   AVISOS (mural interno e painel da TV)
   ===================================================== */
const avisoVigente = a => a.ativo !== false && (!a.validoAte || a.validoAte >= hojeISO());
const PESO_AVISO = { urgente: 0, importante: 1, info: 2 };

router.get("/avisos", rota((req, res) => {
  const lista = ler().avisos
    .filter(a => req.query.todos ? true : avisoVigente(a))
    .filter(a => !req.query.publico || a.publico === req.query.publico || a.publico === "ambos")
    .sort((a, b) => (PESO_AVISO[a.prioridade] - PESO_AVISO[b.prioridade]) || b.createdAt.localeCompare(a.createdAt));
  res.json(lista);
}));

router.post("/avisos", rota((req, res) => {
  const b = req.body;
  const titulo = txt(b.titulo);
  const texto = txt(b.texto);
  if (!titulo) return bad(res, "Informe o título do aviso.");
  if (titulo.length > 80) return bad(res, "Título muito longo (máximo 80 letras).");
  if (texto.length > 300) return bad(res, "Texto muito longo (máximo 300 letras).");

  const prioridade = txt(b.prioridade) || "info";
  const publico = txt(b.publico) || "equipe";
  if (!existe(Hosp.PRIORIDADES_AVISO, prioridade)) return bad(res, "Prioridade inválida.");
  if (!existe(Hosp.PUBLICOS_AVISO, publico)) return bad(res, "Público inválido.");

  // O painel da TV é público: só recepção e administração publicam nele.
  if (publico !== "equipe" && !["admin", "atendimento"].includes(req.sessao.tipo)) {
    return bad(res, "Somente a recepção e a administração publicam no painel da TV.", 403);
  }

  const validoAte = txt(b.validoAte);
  if (validoAte && !dataValida(validoAte)) return bad(res, "Data de validade inválida.");

  const dados = ler();
  const aviso = {
    id: novoId(), titulo, texto, prioridade, publico, validoAte, ativo: true,
    autor: req.sessao.usuario, createdAt: new Date().toISOString()
  };
  dados.avisos.push(aviso);
  gravar(dados);
  res.status(201).json(aviso);
}));

router.delete("/avisos/:id", rota((req, res) => {
  const dados = ler();
  const aviso = dados.avisos.find(a => a.id === Number(req.params.id));
  if (!aviso) return bad(res, "Aviso não encontrado.", 404);

  if (req.sessao.tipo !== "admin" && aviso.autor !== req.sessao.usuario) {
    return bad(res, "Só quem publicou (ou o administrador) pode remover o aviso.", 403);
  }
  dados.avisos = dados.avisos.filter(a => a.id !== aviso.id);
  gravar(dados);
  res.json({ mensagem: "Aviso removido." });
}));

/* =====================================================
   CONTROLE DE ATIVIDADES E ATENDIMENTOS + RELATÓRIOS
   Tudo o que acontece no hospital vira um "evento" com
   o mesmo formato, e as duas telas usam essa lista.
   ===================================================== */
const quem = x => x.profissional || x.registradoPor || x.operador || x.origem || "";

// [coleção, categoria, rótulo, quando, como montar paciente/detalhe]
const FONTES = [
  ["pacientes", "Atendimento", () => "Cadastro na recepção", "createdAt", x => ({ paciente: x.nome, detalhe: x.tipo })],
  ["triagens", "Atendimento", () => "Triagem", "createdAt", x => ({ paciente: x.nome, detalhe: "Risco " + x.risco })],
  ["consultas", "Atendimento", () => "Consulta pediátrica", "createdAt", x => ({ paciente: x.paciente, detalhe: x.diagnostico })],
  ["altas", "Atendimento", () => "Alta / saída", "createdAt", x => ({ paciente: x.paciente, detalhe: x.tipo })],
  ["sessoesPsicologia", "Saúde mental", () => "Sessão de psicologia", "createdAt", x => ({ paciente: x.paciente, detalhe: x.duracao ? x.duracao + " min" : "" })],
  ["avaliacoesPsiquiatria", "Saúde mental", () => "Avaliação psiquiátrica", "createdAt", x => ({ paciente: x.paciente, detalhe: "Risco " + x.nivelRisco })],
  ["apoioFamiliar", "Saúde mental", () => "Apoio a familiar", "createdAt", x => ({ paciente: x.paciente, detalhe: Hosp.nomeDe(Hosp.TIPOS_APOIO_FAMILIAR, x.tipo) })],
  ["encaminhamentos", "Saúde mental", () => "Encaminhamento", "createdAt", x => ({ paciente: x.paciente, detalhe: `${x.destino} (${x.urgencia}) — ${x.status}` })],
  ["sessoesSensorial", "Infantil", () => "Espaço sensorial", "createdAt", x => ({ paciente: x.paciente, detalhe: x.sala })],
  ["registrosPedagogicos", "Infantil", () => "Pedagogia hospitalar", "createdAt", x => ({ paciente: x.paciente, detalhe: x.atividade })],
  ["avaliacoesDesenvolvimento", "Infantil", () => "Avaliação do desenvolvimento", "createdAt", x => ({ paciente: x.paciente, detalhe: x.atencao.length ? "Atenção em " + x.atencao.length + " área(s)" : "" })],
  ["participacoes", "Infantil", x => "Atividade: " + x.atividade, "createdAt", x => ({ paciente: x.paciente, detalhe: x.status }), x => x.status === "realizada"],
  ["presencas", "Infantil", () => "Presença em espaço", "entrouEm", x => ({ paciente: x.paciente, detalhe: x.sala })],
  ["cuidadosEnfermagem", "Enfermagem", x => Hosp.nomeDe(Hosp.TIPOS_ENFERMAGEM, x.tipo), "createdAt", x => ({ paciente: x.paciente, detalhe: x.medicamento || x.descricao })]
];

function eventosDoSistema(dados) {
  const eventos = [];
  FONTES.forEach(([colecao, categoria, rotulo, campoData, montar, filtro]) => {
    (dados[colecao] || []).filter(x => !filtro || filtro(x)).forEach(x => {
      const { paciente, detalhe } = montar(x);
      eventos.push({
        id: colecao + ":" + x.id, colecao, categoria, rotulo: rotulo(x),
        quando: x[campoData], paciente: paciente || "", profissional: quem(x), detalhe: detalhe || ""
      });
    });
  });
  return eventos.sort((a, b) => new Date(b.quando) - new Date(a.quando));
}

// Período pedido: ?desde=ISO&ate=ISO (padrão: últimos 30 dias).
function periodo(query) {
  const ate = query.ate && !isNaN(new Date(query.ate)) ? new Date(query.ate) : new Date();
  const desde = query.desde && !isNaN(new Date(query.desde)) ? new Date(query.desde) : new Date(ate - 30 * 864e5);
  return { desde, ate };
}

router.get("/controle", soAdmin, rota((req, res) => {
  const { desde, ate } = periodo(req.query);
  const busca = txt(req.query.busca).toLowerCase();
  const limite = Math.min(Number(req.query.limite) || 200, 1000);

  const lista = eventosDoSistema(ler())
    .filter(e => { const t = new Date(e.quando); return t >= desde && t <= ate; })
    .filter(e => !req.query.categoria || e.categoria === req.query.categoria)
    .filter(e => !req.query.profissional || e.profissional === req.query.profissional)
    .filter(e => !busca || [e.rotulo, e.paciente, e.profissional, e.detalhe].join(" ").toLowerCase().includes(busca));

  res.json({
    total: lista.length,
    profissionais: [...new Set(eventosDoSistema(ler()).map(e => e.profissional).filter(Boolean))].sort(),
    eventos: lista.slice(0, limite)
  });
}));

const media = lista => lista.length ? +(lista.reduce((s, n) => s + n, 0) / lista.length).toFixed(1) : null;
const contar = (lista, chave) => lista.reduce((m, x) => { const k = chave(x); m[k] = (m[k] || 0) + 1; return m; }, {});

router.get("/relatorios", soAdmin, rota((req, res) => {
  const dados = ler();
  const { desde, ate } = periodo(req.query);
  const fuso = Number(req.query.fuso) || 0; // minutos, como getTimezoneOffset()

  const dentro = x => { const t = new Date(x); return t >= desde && t <= ate; };
  const diaLocal = iso => new Date(new Date(iso) - fuso * 6e4).toISOString().slice(0, 10);
  const naJanela = (colecao, campo = "createdAt") => dados[colecao].filter(x => dentro(x[campo]));

  const eventos = eventosDoSistema(dados).filter(e => dentro(e.quando));

  const porProfissional = Object.entries(contar(eventos.filter(e => e.profissional), e => e.profissional))
    .map(([nome, total]) => ({ nome, total })).sort((a, b) => b.total - a.total).slice(0, 15);

  const porDia = Object.entries(contar(eventos, e => diaLocal(e.quando)))
    .map(([data, total]) => ({ data, total })).sort((a, b) => a.data.localeCompare(b.data));

  const sessoesPsi = naJanela("sessoesPsicologia");
  const ganho = sessoesPsi.filter(s => s.humorAntes != null && s.humorDepois != null).map(s => s.humorDepois - s.humorAntes);
  const participacoes = naJanela("participacoes").filter(p => p.status === "realizada");
  const encaminhamentos = naJanela("encaminhamentos");
  const atendidos = encaminhamentos.filter(e => e.status === "atendido" && e.atendidoEm);
  const presencas = naJanela("presencas", "entrouEm");

  const ocupacao = dados.salas.map(sala => {
    const dela = presencas.filter(p => p.salaId === sala.id);
    const minutosTotal = dela.filter(p => p.saiuEm).reduce((s, p) => s + (new Date(p.saiuEm) - new Date(p.entrouEm)) / 6e4, 0);
    return { sala: sala.nome, tipo: sala.tipo, entradas: dela.length, horas: +(minutosTotal / 60).toFixed(1) };
  }).filter(s => s.entradas).sort((a, b) => b.entradas - a.entradas);

  const programacao = dados.programacao.filter(p => dentro(p.data + "T12:00:00"));
  const prescricoesComAlerta = naJanela("consultas").filter(c => (c.alertasIA || []).some(a => a.gravidade === "alta"));
  const medicacoesComAlerta = naJanela("cuidadosEnfermagem").filter(c => (c.alertasIA || []).some(a => a.gravidade === "alta"));

  res.json({
    periodo: { desde: desde.toISOString(), ate: ate.toISOString() },
    totais: {
      eventos: eventos.length,
      criancasAtendidas: new Set(eventos.map(e => e.paciente).filter(Boolean)).size,
      porCategoria: contar(eventos, e => e.categoria),
      porTipo: Object.entries(contar(eventos, e => e.rotulo.startsWith("Atividade:") ? "Atividade realizada" : e.rotulo))
        .map(([rotulo, total]) => ({ rotulo, total })).sort((a, b) => b.total - a.total)
    },
    atendimento: {
      cadastros: naJanela("pacientes").length, triagens: naJanela("triagens").length,
      consultas: naJanela("consultas").length, altas: naJanela("altas").length,
      riscos: contar(naJanela("triagens"), t => t.risco)
    },
    saudeMental: {
      sessoesPsicologia: sessoesPsi.length,
      ganhoMedioDeHumor: media(ganho),
      avaliacoesPsiquiatria: naJanela("avaliacoesPsiquiatria").length,
      avaliacoesRiscoAlto: naJanela("avaliacoesPsiquiatria").filter(a => a.alertaRisco).length,
      apoioFamiliar: naJanela("apoioFamiliar").length
    },
    infantil: {
      atividadesRealizadas: participacoes.length,
      reacaoMedia: media(participacoes.filter(p => p.reacao).map(p => p.reacao)),
      sessoesSensorial: naJanela("sessoesSensorial").length,
      registrosPedagogicos: naJanela("registrosPedagogicos").length,
      avaliacoesDesenvolvimento: naJanela("avaliacoesDesenvolvimento").length,
      programadas: programacao.length,
      programadasRealizadas: programacao.filter(p => p.status === "realizada").length,
      criancasInscritas: programacao.reduce((s, p) => s + p.inscritos.length, 0)
    },
    encaminhamentos: {
      total: encaminhamentos.length,
      pendentes: encaminhamentos.filter(e => e.status === "pendente").length,
      atendidos: atendidos.length,
      cancelados: encaminhamentos.filter(e => e.status === "cancelado").length,
      horasMediasParaAtender: media(atendidos.map(e => (new Date(e.atendidoEm) - new Date(e.createdAt)) / 36e5))
    },
    enfermagem: {
      registros: naJanela("cuidadosEnfermagem").length,
      medicacoes: naJanela("cuidadosEnfermagem").filter(c => c.tipo === "medicacao").length
    },
    ia: {
      prescricoesComAlertaGrave: prescricoesComAlerta.length,
      prescricoesMantidasComCiencia: prescricoesComAlerta.filter(c => c.cienteIA).length,
      medicacoesComAlertaGrave: medicacoesComAlerta.length,
      medicacoesMantidasComCiencia: medicacoesComAlerta.filter(c => c.cienteIA).length
    },
    farmacia: {
      zerado: dados.estoque.filter(i => i.quantidade <= 0).length,
      baixo: dados.estoque.filter(i => i.quantidade > 0 && i.quantidade < 10).length
    },
    ocupacaoSalas: ocupacao,
    porProfissional,
    porDia
  });
}));

/* =====================================================
   CONTADORES DO MENU LATERAL
   (pedidos pendentes e alertas, mostrados como selinhos)
   ===================================================== */
router.get("/menu/contadores", rota((req, res) => {
  const dados = ler();
  const pendentes = dados.encaminhamentos.filter(e => e.status === "pendente");
  const doDestino = destino => pendentes.filter(e => e.destino === destino).length;

  const contadores = {
    psicologia: doDestino("psicologia"),
    psiquiatria: doDestino("psiquiatria"),
    pedagogia: doDestino("pedagogia"),
    acolhimento: doDestino("bemestar"),
    encaminhamentos: pendentes.length,
    avisos: dados.avisos.filter(a => avisoVigente(a) && a.prioridade !== "info").length,
    triagem: dados.pacientes.filter(p => p.status === "triagem").length,
    medico: dados.pacientes.filter(p => p.status === "aguardando_medico").length,
    altas: dados.pacientes.filter(p => p.status === "aguardando_alta").length
  };

  if (pode(req.sessao, "painel")) {
    contadores.ia = alertasGerais(dados).filter(a => a.gravidade === "alta" && !a.ciente).length;
  }
  res.json(contadores);
}));

module.exports = router;
