/* =====================================================
   ia/permissoes.js — o que cada profissional pode usar
   da Sentinela Intelligence.

   Cada setor tem um conjunto padrão. O administrador pode
   trocar o conjunto de uma pessoa (campo iaPermissoes na
   conta). O administrador sempre tem tudo.
   ===================================================== */

const RECURSOS = [
  { id: "prescricao",  nome: "Conferir prescrições",             descricao: "Alertas de dose, alergia, duplicidade e diagnóstico ao prescrever." },
  { id: "medicacao",   nome: "Conferir administração de medicamentos", descricao: "Compara o que foi administrado com a prescrição (dose, intervalo, alergia)." },
  { id: "conferencia", nome: "Conferir dados do paciente",       descricao: "Inconsistências de cadastro e triagem de uma criança." },
  { id: "painel",      nome: "Ver o painel de alertas",          descricao: "Lista geral de alertas do hospital." },
  { id: "auditoria",   nome: "Consultar a trilha de auditoria",  descricao: "Quem fez o quê e quando; acesso a registros sensíveis." }
];

const TODOS = RECURSOS.map(r => r.id);

const PADRAO = {
  admin:        TODOS,
  medico:       ["prescricao", "conferencia", "painel"],
  enfermagem:   ["medicacao", "conferencia", "painel"],
  triagem:      ["conferencia"],
  atendimento:  ["conferencia"],
  almoxarifado: ["painel"],
  psicologia:   [],
  psiquiatria:  [],
  pedagogia:    [],
  bemestar:     []
};

// conta = { tipo, iaPermissoes?, mestre? }
function permissoesDe(conta) {
  if (!conta) return [];
  if (conta.mestre || conta.tipo === "admin") return TODOS;
  if (Array.isArray(conta.iaPermissoes)) return conta.iaPermissoes.filter(id => TODOS.includes(id));
  return PADRAO[conta.tipo] || [];
}

const pode = (conta, recurso) => permissoesDe(conta).includes(recurso);

// Middleware: exige uma permissão da IA.
const exigirIA = recurso => (req, res, next) => {
  if (!pode(req.sessao, recurso)) {
    return res.status(403).json({ erro: "Seu perfil não tem acesso a este recurso da Sentinela Intelligence." });
  }
  next();
};

module.exports = { RECURSOS, TODOS, PADRAO, permissoesDe, pode, exigirIA };
