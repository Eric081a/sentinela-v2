/* =====================================================
   ia/index.js — Sentinela Intelligence (rotas em /ia).

   É um motor de conferência com regras explicáveis:
   apoia o profissional, não decide por ele.

   Rotas:
     GET  /ia/status                 regras, aviso e meu acesso
     POST /ia/prescricao/verificar   confere uma prescrição
     POST /ia/medicacao/verificar    confere uma administração
     GET  /ia/paciente/:id           confere cadastro e triagem
     GET  /ia/alertas                painel geral de alertas
     GET  /ia/auditoria              trilha de auditoria
     GET  /ia/permissoes             (admin) quem pode o quê
     PUT  /ia/permissoes/:usuario    (admin) muda as permissões
   ===================================================== */

const express = require("express");

const { ler, gravar } = require("../banco");
const { txt, bad, rota } = require("../util");
const { exigirTipo } = require("../auth");
const { buscarPaciente, ultimaTriagem } = require("../apoio");

const { REGRAS, porGravidade } = require("./catalogo");
const { verificarPrescricao } = require("./prescricao");
const { verificarAdministracao } = require("./medicacao");
const { conferirPaciente, alertasGerais } = require("./paciente");
const { RECURSOS, TODOS, PADRAO, permissoesDe, pode, exigirIA } = require("./permissoes");
const Auditoria = require("./auditoria");

const router = express.Router();

/* ---------- Funções usadas também pelo server.js ---------- */

// Confere a prescrição de uma consulta (se a pessoa tem essa permissão).
function conferirConsulta(dados, sessao, { pacienteId, diagnostico, prescricoes }) {
  if (!pode(sessao, "prescricao")) return [];

  return verificarPrescricao({
    paciente: buscarPaciente(dados, pacienteId),
    triagem: ultimaTriagem(dados, pacienteId),
    diagnostico,
    itens: prescricoes,
    estoque: dados.estoque
  }).sort(porGravidade);
}

const temAlertaGrave = alertas => alertas.some(a => a.gravidade === "alta");

/* ---------- Status ---------- */
router.get("/status", rota((req, res) => {
  res.json({
    nome: "Sentinela Intelligence",
    versao: "1.0",
    motor: "Regras clínicas e de consistência (determinístico e explicável)",
    aviso: "Apoio à decisão. Não substitui o julgamento do profissional de saúde.",
    regras: Object.entries(REGRAS).map(([codigo, r]) => ({ codigo, ...r })),
    recursos: RECURSOS,
    meuAcesso: permissoesDe(req.sessao)
  });
}));

/* ---------- Conferências em tempo real ---------- */
router.post("/prescricao/verificar", exigirIA("prescricao"), rota((req, res) => {
  const dados = ler();
  const alertas = conferirConsulta(dados, req.sessao, {
    pacienteId: req.body.pacienteId,
    diagnostico: txt(req.body.diagnostico),
    prescricoes: Array.isArray(req.body.itens) ? req.body.itens : []
  });
  res.json({ alertas });
}));

router.post("/medicacao/verificar", exigirIA("medicacao"), rota((req, res) => {
  const dados = ler();
  if (!buscarPaciente(dados, req.body.pacienteId)) return bad(res, "Criança não encontrada.", 404);

  res.json({ alertas: verificarAdministracao(dados, req.body).sort(porGravidade) });
}));

router.get("/paciente/:id", exigirIA("conferencia"), rota((req, res) => {
  const dados = ler();
  const paciente = buscarPaciente(dados, req.params.id);
  if (!paciente) return bad(res, "Criança não encontrada.", 404);

  res.json({ alertas: conferirPaciente(dados, paciente) });
}));

/* ---------- Painel geral ---------- */
router.get("/alertas", exigirIA("painel"), rota((req, res) => {
  const alertas = alertasGerais(ler());
  const contar = g => alertas.filter(a => a.gravidade === g && !a.ciente).length;

  res.json({
    resumo: { alta: contar("alta"), media: contar("media"), baixa: contar("baixa") },
    alertas
  });
}));

/* ---------- Auditoria ---------- */
router.get("/auditoria", exigirIA("auditoria"), rota((req, res) => {
  const { usuario, desde, ate, busca, somenteIA } = req.query;
  const limite = Math.min(Number(req.query.limite) || 100, 500);
  const termo = txt(busca).toLowerCase();

  const de = desde ? new Date(desde) : null;
  const ateData = ate ? new Date(ate) : null;

  const lista = ler().auditoria
    .filter(a => !usuario || a.usuario === usuario)
    .filter(a => !de || new Date(a.quando) >= de)
    .filter(a => !ateData || new Date(a.quando) <= ateData)
    .filter(a => !somenteIA || a.ia)
    .filter(a => !termo || [a.acao, a.usuario, a.paciente, a.detalhe].join(" ").toLowerCase().includes(termo));

  res.json({
    total: lista.length,
    usuarios: [...new Set(ler().auditoria.map(a => a.usuario))].sort(),
    itens: lista.slice().reverse().slice(0, limite)
  });
}));

/* ---------- Permissões (somente administrador) ---------- */
router.get("/permissoes", exigirTipo("admin"), rota((req, res) => {
  const contas = ler().usuarios.map(u => ({
    usuario: u.usuario,
    tipo: u.tipo,
    personalizado: Array.isArray(u.iaPermissoes),
    permissoes: permissoesDe(u)
  }));
  res.json({ recursos: RECURSOS, padrao: PADRAO, contas });
}));

// Corpo: { permissoes: ["prescricao", ...] } ou { permissoes: null } para voltar ao padrão do setor.
router.put("/permissoes/:usuario", exigirTipo("admin"), rota((req, res) => {
  const dados = ler();
  const conta = dados.usuarios.find(u => u.usuario === req.params.usuario);
  if (!conta) return bad(res, "Usuário não encontrado.", 404);
  if (conta.tipo === "admin") return bad(res, "O administrador sempre tem todas as permissões.", 409);

  const pedidas = req.body.permissoes;
  if (pedidas === null) {
    delete conta.iaPermissoes;
  } else if (Array.isArray(pedidas) && pedidas.every(id => TODOS.includes(id))) {
    conta.iaPermissoes = [...new Set(pedidas)];
  } else {
    return bad(res, "Lista de permissões inválida.");
  }

  gravar(dados);
  req.auditoriaExtra = { detalhe: `${conta.usuario}: ${permissoesDe(conta).join(", ") || "nenhuma"}` };
  res.json({ usuario: conta.usuario, permissoes: permissoesDe(conta) });
}));

module.exports = { router, conferirConsulta, temAlertaGrave, Auditoria, permissoesDe };
