/* =====================================================
   ia/paciente.js — conferência de cadastro, triagem e
   situação geral (painel de alertas da Sentinela).
   ===================================================== */

const Ped = require("../../frontend/js/pediatria.js");
const { alerta, porGravidade, normalizar } = require("./catalogo");
const { verificarPrescricao } = require("./prescricao");
const { ultimaTriagem } = require("../apoio");

const HORA = 36e5;

/* ---------- CPF ---------- */
function cpfValido(texto) {
  const c = String(texto || "").replace(/\D/g, "");
  if (c.length !== 11 || /^(\d)\1+$/.test(c)) return false;

  const digito = tamanho => {
    let soma = 0;
    for (let i = 0; i < tamanho; i++) soma += Number(c[i]) * (tamanho + 1 - i);
    const resto = (soma * 10) % 11;
    return resto === 10 ? 0 : resto;
  };
  return digito(9) === Number(c[9]) && digito(10) === Number(c[10]);
}

/* ---------- Peso mediano aproximado por idade (kg) ---------- */
// Pontos [meses, kg] — referência aproximada (OMS) só para achar valores muito fora do esperado.
const PESO_MEDIO = [[0, 3.3], [1, 4.5], [3, 6.4], [6, 7.9], [12, 9.6], [24, 12.2], [36, 14.3],
  [48, 16.3], [60, 18.3], [72, 20.5], [96, 25.5], [120, 32], [144, 41], [180, 55], [216, 62]];

function pesoEsperado(meses) {
  for (let i = 1; i < PESO_MEDIO.length; i++) {
    const [m1, p1] = PESO_MEDIO[i - 1];
    const [m2, p2] = PESO_MEDIO[i];
    if (meses <= m2) return p1 + ((p2 - p1) * (meses - m1)) / (m2 - m1);
  }
  return PESO_MEDIO[PESO_MEDIO.length - 1][1];
}

/* ---------- Conferência de uma criança ---------- */
function conferirPaciente(dados, paciente) {
  const alertas = [];
  const com = (codigo, detalhe, extra = {}) =>
    alertas.push(alerta(codigo, detalhe, { pacienteId: paciente.id, paciente: paciente.nome, ...extra }));

  const idade = Ped.idade(paciente.nascimento);
  if (!idade) {
    com("NASCIMENTO_INVALIDO", "A data de nascimento não é válida. Isso afeta doses e classificação.");
  } else if (idade.meses >= 216) {
    com("ADULTO_PEDIATRICO", `Idade registrada: ${idade.texto}. Confirme a data de nascimento ou encaminhe ao serviço adequado.`);
  }

  if (paciente.cpf) {
    if (!cpfValido(paciente.cpf)) {
      com("CPF_INVALIDO", `O CPF "${paciente.cpf}" não passa na conferência dos dígitos.`);
    } else {
      const digitos = paciente.cpf.replace(/\D/g, "");
      const outro = dados.pacientes.find(p => p.id !== paciente.id && String(p.cpf || "").replace(/\D/g, "") === digitos);
      if (outro) com("CPF_REPETIDO", `Mesmo CPF do cadastro de ${outro.nome}.`);
    }
  }

  const duplicado = dados.pacientes.find(p =>
    p.id !== paciente.id &&
    normalizar(p.nome) === normalizar(paciente.nome) &&
    p.nascimento === paciente.nascimento
  );
  if (duplicado) com("POSSIVEL_DUPLICIDADE", "Já existe cadastro com o mesmo nome e data de nascimento.");

  const telefone = String(paciente.telefone || "").replace(/\D/g, "");
  if (paciente.telefone && (telefone.length < 10 || telefone.length > 11)) {
    com("TELEFONE_INVALIDO", `O telefone "${paciente.telefone}" não parece completo (DDD + número).`);
  }

  const triagem = ultimaTriagem(dados, paciente.id);
  if (triagem && idade) {
    const esperado = pesoEsperado(idade.meses);
    if (triagem.peso < esperado * 0.5 || triagem.peso > esperado * 2) {
      com("PESO_IMPLAUSIVEL", `Peso ${triagem.peso} kg para ${idade.texto} (esperado em torno de ${esperado.toFixed(1)} kg). Confirme se o valor e a unidade estão corretos.`);
    }

    const recalculado = Ped.classificar({
      meses: idade.meses, temp: triagem.temperatura, fc: triagem.fc,
      fr: triagem.fr, spo2: triagem.spo2, sinais: triagem.sinais
    });
    if (Ped.ORD.indexOf(triagem.risco) < Ped.ORD.indexOf(recalculado.risco)) {
      com("RISCO_SUBCLASSIFICADO", `Registrado: ${triagem.risco}. Pelos sinais vitais e sinais de alerta o cálculo dá: ${recalculado.risco}.`);
    }
  }

  return alertas.sort(porGravidade);
}

/* ---------- Painel geral ---------- */
function alertasGerais(dados) {
  const lista = [];
  const agora = Date.now();
  const ativos = dados.pacientes.filter(p => p.status !== "encerrado");

  // Cadastro e triagem das crianças ativas.
  ativos.forEach(p => lista.push(...conferirPaciente(dados, p)));

  // Prescrições das últimas 48 h (reconferidas) e as que o médico manteve ciente.
  dados.consultas.filter(c => agora - new Date(c.createdAt) < 48 * HORA).forEach(consulta => {
    const paciente = dados.pacientes.find(p => p.id === Number(consulta.pacienteId));
    verificarPrescricao({
      paciente, triagem: ultimaTriagem(dados, consulta.pacienteId),
      diagnostico: consulta.diagnostico, itens: consulta.prescricoes, estoque: dados.estoque
    }).filter(a => a.gravidade === "alta").forEach(a => lista.push({
      ...a, pacienteId: paciente && paciente.id, paciente: consulta.paciente,
      origem: "Prescrição de " + new Date(consulta.createdAt).toLocaleString("pt-BR"),
      ciente: !!consulta.cienteIA, justificativa: consulta.cienteIA && consulta.cienteIA.justificativa
    }));
  });

  // Medicações administradas com alerta grave nas últimas 48 h.
  dados.cuidadosEnfermagem
    .filter(c => c.tipo === "medicacao" && agora - new Date(c.createdAt) < 48 * HORA)
    .forEach(c => (c.alertasIA || []).filter(a => a.gravidade === "alta").forEach(a => lista.push({
      ...a, pacienteId: c.pacienteId, paciente: c.paciente,
      origem: "Administração de " + new Date(c.createdAt).toLocaleString("pt-BR"),
      ciente: !!c.cienteIA, justificativa: c.cienteIA && c.cienteIA.justificativa
    })));

  // Fila de atendimento.
  dados.triagens.filter(t => t.status === "aguardando_medico").forEach(t => {
    const espera = Math.round((agora - new Date(t.createdAt)) / 6e4);
    const alvo = Ped.ALVO[t.risco];
    if (espera > Math.max(alvo * 2, 15)) {
      lista.push(alerta("ESPERA_ACIMA_ALVO", `${t.nome} (${t.risco}) espera há ${espera} min; o tempo-alvo é ${alvo} min.`, { pacienteId: t.pacienteId, paciente: t.nome }));
    }
  });

  // Encaminhamentos parados.
  dados.encaminhamentos.filter(e => e.status === "pendente").forEach(e => {
    const horas = (agora - new Date(e.createdAt)) / HORA;
    if (e.urgencia === "urgente" && horas > 2) {
      lista.push(alerta("ENCAMINHAMENTO_URGENTE_PARADO", `${e.paciente}: urgente para ${e.destino} há ${horas.toFixed(1)} h.`, { pacienteId: e.pacienteId, paciente: e.paciente }));
    } else if (horas > 24) {
      lista.push(alerta("ENCAMINHAMENTO_ATRASADO", `${e.paciente}: pendente para ${e.destino} há ${Math.round(horas)} h.`, { pacienteId: e.pacienteId, paciente: e.paciente }));
    }
  });

  // Dor forte nas últimas 3 h e avaliações psiquiátricas com alerta nas últimas 24 h.
  dados.humores.filter(h => h.dor != null && h.dor >= 7 && agora - new Date(h.createdAt) < 3 * HORA).forEach(h => {
    lista.push(alerta("DOR_ALTA_RECENTE", `${h.paciente} registrou dor ${h.dor}/10.`, { pacienteId: h.pacienteId, paciente: h.paciente }));
  });
  dados.avaliacoesPsiquiatria.filter(a => a.alertaRisco && agora - new Date(a.createdAt) < 24 * HORA).forEach(a => {
    lista.push(alerta("RISCO_PSIQUIATRICO", `${a.paciente}: avaliação com risco ${a.nivelRisco}. Conduta: ${a.conduta}.`, { pacienteId: a.pacienteId, paciente: a.paciente }));
  });

  // Estoque dos medicamentos do formulário.
  dados.estoque.forEach(item => {
    if (item.quantidade <= 0) lista.push(alerta("ESTOQUE_ZERADO", `${item.nome} está zerado.`));
    else if (item.quantidade < 10) lista.push(alerta("ESTOQUE_BAIXO", `${item.nome}: restam ${item.quantidade} ${item.unidade || ""}.`));
  });

  // Gravidade; os já reconhecidos pelo profissional vão para o fim de cada nível.
  return lista.sort((a, b) => porGravidade(a, b) || (!!a.ciente - !!b.ciente));
}

module.exports = { conferirPaciente, alertasGerais, cpfValido, pesoEsperado };
