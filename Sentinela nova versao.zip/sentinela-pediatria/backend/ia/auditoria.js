/* =====================================================
   ia/auditoria.js — trilha de auditoria.
   Registra QUEM fez O QUÊ e QUANDO. Não guarda o conteúdo
   dos registros clínicos (só a ação e a criança envolvida).
   ===================================================== */

const { ler, gravar } = require("../banco");
const { novoId } = require("../util");

const LIMITE_REGISTROS = 5000;

// [método, caminho, descrição]
const ACOES = [
  ["POST", /^\/usuarios?$/, "Cadastrou usuário"],
  ["PUT", /^\/usuarios\/[^/]+$/, "Editou usuário"],
  ["DELETE", /^\/usuarios\/[^/]+$/, "Excluiu usuário"],
  ["POST", /^\/atendimento$/, "Cadastrou criança na recepção"],
  ["POST", /^\/triagem$/, "Registrou triagem"],
  ["POST", /^\/chamar$/, "Chamou paciente no painel"],
  ["POST", /^\/consulta$/, "Registrou consulta e prescrição"],
  ["POST", /^\/alta$/, "Registrou alta / saída"],
  ["POST", /^\/estoque$/, "Registrou entrada no estoque"],
  ["POST", /^\/humor$/, "Registrou humor ou dor"],
  ["POST", /^\/encaminhamento$/, "Criou encaminhamento"],
  ["PUT", /^\/encaminhamentos\/\d+$/, "Cancelou encaminhamento"],
  ["POST", /^\/psicologia\/sessao$/, "Registrou sessão de psicologia"],
  ["POST", /^\/psiquiatria\/avaliacao$/, "Registrou avaliação psiquiátrica"],
  ["POST", /^\/atividades\/participacao$/, "Agendou atividade para a criança"],
  ["PUT", /^\/atividades\/participacoes\/\d+$/, "Atualizou atividade da criança"],
  ["POST", /^\/sensorial\/sessao$/, "Registrou sessão no espaço sensorial"],
  ["POST", /^\/pedagogia\/registro$/, "Registrou atividade pedagógica"],
  ["POST", /^\/desenvolvimento\/avaliacao$/, "Registrou avaliação do desenvolvimento"],
  ["POST", /^\/familia\/atendimento$/, "Registrou apoio a familiar"],
  ["POST", /^\/enfermagem\/registro$/, "Registrou cuidado de enfermagem"],
  ["POST", /^\/programacao$/, "Criou atividade na programação"],
  ["PUT", /^\/programacao\/\d+$/, "Atualizou atividade da programação"],
  ["POST", /^\/programacao\/\d+\/inscrever$/, "Inscreveu criança em atividade"],
  ["DELETE", /^\/programacao\/\d+\/inscritos\/\d+$/, "Removeu criança de atividade"],
  ["POST", /^\/salas$/, "Cadastrou sala"],
  ["PUT", /^\/salas\/\d+$/, "Editou sala"],
  ["DELETE", /^\/salas\/\d+$/, "Excluiu sala"],
  ["POST", /^\/salas\/\d+\/entrada$/, "Registrou entrada de criança na sala"],
  ["POST", /^\/salas\/\d+\/saida$/, "Registrou saída de criança da sala"],
  ["POST", /^\/reservas$/, "Reservou sala"],
  ["DELETE", /^\/reservas\/\d+$/, "Cancelou reserva de sala"],
  ["POST", /^\/profissionais$/, "Cadastrou profissional"],
  ["PUT", /^\/profissionais\/\d+$/, "Editou profissional"],
  ["DELETE", /^\/profissionais\/\d+$/, "Excluiu profissional"],
  ["POST", /^\/setores$/, "Cadastrou setor"],
  ["PUT", /^\/setores\/\d+$/, "Editou setor"],
  ["DELETE", /^\/setores\/\d+$/, "Excluiu setor"],
  ["POST", /^\/avisos$/, "Publicou aviso"],
  ["DELETE", /^\/avisos\/\d+$/, "Removeu aviso"],
  ["PUT", /^\/ia\/permissoes\/[^/]+$/, "Alterou permissões da IA"]
];

// Leituras de dados sensíveis também ficam registradas.
const LEITURAS = [
  [/^\/psicologia\/sessoes$/, "Consultou sessões de psicologia"],
  [/^\/psiquiatria\/avaliacoes$/, "Consultou avaliações psiquiátricas"],
  [/^\/acompanhamento\/\d+$/, "Consultou acompanhamento emocional"],
  [/^\/familia\/atendimentos$/, "Consultou apoio a familiares"],
  [/^\/enfermagem\/registros$/, "Consultou registros de enfermagem"],
  [/^\/ia\/auditoria$/, "Consultou a trilha de auditoria"]
];

function descrever(metodo, caminho) {
  if (metodo !== "GET") {
    const achou = ACOES.find(([m, regra]) => m === metodo && regra.test(caminho));
    return achou ? achou[2] : null;
  }
  const leitura = LEITURAS.find(([regra]) => regra.test(caminho));
  return leitura ? leitura[1] : null;
}

// Acrescenta um registro (quem chama grava o banco).
function registrar(dados, entrada) {
  dados.auditoria.push({ id: novoId(), quando: new Date().toISOString(), ...entrada });
  if (dados.auditoria.length > LIMITE_REGISTROS) {
    dados.auditoria.splice(0, dados.auditoria.length - LIMITE_REGISTROS);
  }
}

// Registro avulso (ex.: login).
function auditar(entrada) {
  const dados = ler();
  registrar(dados, entrada);
  gravar(dados);
}

// Evita encher a trilha: a mesma leitura pela mesma pessoa em 5 min conta uma vez.
const lidasRecentemente = new Map();

function middleware(req, res, next) {
  res.on("finish", () => {
    try {
      if (!req.sessao) return;

      const caminho = req.originalUrl.split("?")[0];
      const acao = descrever(req.method, caminho);
      if (!acao) return;

      const status = res.statusCode;
      const deuCerto = status < 400;
      const relevante = deuCerto || status === 401 || status === 403 || status >= 500 || req.auditoriaExtra;
      if (!relevante) return;

      if (req.method === "GET") {
        const chave = req.sessao.usuario + "|" + caminho;
        if (Date.now() - (lidasRecentemente.get(chave) || 0) < 3e5) return;
        lidasRecentemente.set(chave, Date.now());
      }

      const dados = ler();
      const extra = req.auditoriaExtra || {};
      const pacienteId = req.body && req.body.pacienteId;
      const paciente = extra.paciente ||
        (pacienteId && (dados.pacientes.find(p => p.id === Number(pacienteId)) || {}).nome) ||
        (/^\/acompanhamento\/(\d+)$/.test(caminho) && (dados.pacientes.find(p => p.id === Number(caminho.split("/")[2])) || {}).nome) ||
        null;

      registrar(dados, {
        usuario: req.sessao.usuario,
        tipo: req.sessao.tipo,
        acao,
        metodo: req.method,
        rota: caminho,
        status,
        resultado: deuCerto ? "ok" : (status === 401 || status === 403 ? "negado" : "erro"),
        paciente,
        detalhe: extra.detalhe || null,
        ia: !!extra.ia
      });
      gravar(dados);
    } catch (erro) {
      console.error("Falha ao registrar auditoria:", erro.message);
    }
  });
  next();
}

module.exports = { registrar, auditar, middleware, descrever };
