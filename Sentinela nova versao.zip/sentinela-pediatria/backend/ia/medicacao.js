/* =====================================================
   ia/medicacao.js — conferência da administração de
   medicamentos pela enfermagem (prescrito x administrado).
   ===================================================== */

const { alerta, alergiaConflita } = require("./catalogo");
const { formularioDe, lerDose, numero } = require("./prescricao");
const { ultimaTriagem } = require("../apoio");

const HORA = 36e5;

// "6/6 h" -> 6 · "1x ao dia" -> 24
function horasDoIntervalo(intervalo) {
  const achou = /^(\d+)\/\d+\s*h/.exec(intervalo || "");
  if (achou) return Number(achou[1]);
  return /1x/.test(intervalo || "") ? 24 : null;
}

function ultimaConsulta(dados, pacienteId) {
  return dados.consultas.filter(c => Number(c.pacienteId) === Number(pacienteId)).slice(-1)[0] || null;
}

// Doses já administradas (registros de enfermagem) deste medicamento.
function dosesAnteriores(dados, pacienteId, idMedicamento) {
  return dados.cuidadosEnfermagem.filter(c =>
    c.tipo === "medicacao" &&
    Number(c.pacienteId) === Number(pacienteId) &&
    c.medicamentoId === idMedicamento
  );
}

function verificarAdministracao(dados, { pacienteId, medicamento, doseMg, doseMl, quando }) {
  const alertas = [];
  const f = formularioDe({ nome: medicamento });
  const agora = quando ? new Date(quando) : new Date();
  const consulta = ultimaConsulta(dados, pacienteId);

  if (!consulta || !(consulta.prescricoes || []).length) {
    alertas.push(alerta("SEM_PRESCRICAO", "Não há prescrição registrada para esta criança. Confirme com o médico antes de administrar."));
    return alertas;
  }

  if (Date.now() - new Date(consulta.createdAt) > 7 * 24 * HORA) {
    alertas.push(alerta("PRESCRICAO_ANTIGA", "A última prescrição é de " + new Date(consulta.createdAt).toLocaleDateString("pt-BR") + ". Confirme se continua valendo."));
  }

  const prescrito = consulta.prescricoes.find(item => {
    const outro = formularioDe(item);
    return f ? outro && outro.id === f.id : item.nome && item.nome.toLowerCase() === String(medicamento).toLowerCase();
  });

  if (!prescrito) {
    alertas.push(alerta("NAO_PRESCRITO", `${medicamento} não está na última prescrição (${consulta.prescricoes.map(p => p.nome).join(", ")}).`));
    return alertas;
  }
  if (!f) return alertas;

  const triagem = ultimaTriagem(dados, pacienteId);
  const termo = triagem ? alergiaConflita(triagem.alergia, f.id) : null;
  if (termo) {
    alertas.push(alerta("ALERGIA", `${f.nome}: a triagem registra alergia ("${termo}"). Alergia informada: ${triagem.alergia}.`));
  }

  // Dose administrada x prescrita (aceita mg ou mL).
  const dada = numero(doseMg) ?? (numero(doseMl) != null ? numero(doseMl) * f.conc : null);
  const { mg: prescritaMg } = lerDose(prescrito);
  if (dada != null && prescritaMg) {
    const diferenca = Math.abs(dada - prescritaMg) / prescritaMg;
    if (diferenca > 0.1) {
      alertas.push(alerta("DOSE_DIVERGENTE", `Administrado ${+dada.toFixed(1)} mg; prescrito ${prescritaMg} mg (${Math.round(diferenca * 100)}% de diferença).`, { gravidade: diferenca > 0.25 ? "alta" : "media" }));
    }
  }

  // Intervalo e limite diário.
  const anteriores = dosesAnteriores(dados, pacienteId, f.id)
    .map(c => new Date(c.quando || c.createdAt))
    .filter(data => data <= agora)
    .sort((a, b) => b - a);

  const textoIntervalo = /\d+\/\d+\s*h|1x ao dia/.exec(prescrito.texto || "");
  const intervalo = horasDoIntervalo(textoIntervalo ? textoIntervalo[0] : f.intervalo);
  if (anteriores.length && intervalo) {
    const horas = (agora - anteriores[0]) / HORA;
    if (horas < intervalo * 0.9) {
      alertas.push(alerta("INTERVALO_CURTO", `A última dose de ${f.nome} foi há ${horas.toFixed(1)} h; o intervalo prescrito é de ${intervalo} h.`));
    }
  }

  const vezes = numero(prescrito.vezes) || f.vezes;
  const nas24h = anteriores.filter(data => agora - data < 24 * HORA).length;
  if (nas24h >= vezes) {
    alertas.push(alerta("LIMITE_DIARIO", `Já foram administradas ${nas24h} dose(s) de ${f.nome} nas últimas 24 h; o prescrito é ${vezes} por dia.`));
  }

  return alertas;
}

module.exports = { verificarAdministracao, horasDoIntervalo, ultimaConsulta };
