/* =====================================================
   ia/catalogo.js — regras e vocabulário da Sentinela Intelligence.

   A IA do Sentinela é um motor de CONFERÊNCIA: aplica regras
   claras e explicáveis (doses, alergias, duplicidades,
   consistência de cadastro) e avisa o profissional.
   Ela apoia a decisão; quem decide é sempre o profissional.

   ATENÇÃO: faixas e regras clínicas são de apoio/demonstração
   e precisam ser validadas pelo protocolo do hospital.
   ===================================================== */

const GRAVIDADES = { alta: 0, media: 1, baixa: 2 };

/* ---------- Catálogo de regras (aparece na tela da IA) ---------- */
const REGRAS = {
  // Prescrição
  SEM_PESO:            { area: "Prescrição", gravidade: "media", titulo: "Peso não registrado" },
  ALERGIA:             { area: "Prescrição", gravidade: "alta",  titulo: "Possível alergia ao medicamento" },
  DOSE_ACIMA:          { area: "Prescrição", gravidade: "alta",  titulo: "Dose acima da faixa usual" },
  DOSE_ABAIXO:         { area: "Prescrição", gravidade: "baixa", titulo: "Dose abaixo da faixa usual" },
  DOSE_DIARIA:         { area: "Prescrição", gravidade: "alta",  titulo: "Dose diária acima do limite" },
  DOSE_MAXIMA:         { area: "Prescrição", gravidade: "alta",  titulo: "Dose acima do máximo por administração" },
  IDADE_MINIMA:        { area: "Prescrição", gravidade: "alta",  titulo: "Idade ou peso abaixo do recomendado" },
  CONVERSAO_MG_ML:     { area: "Prescrição", gravidade: "media", titulo: "Valores em mg e mL não conferem" },
  DUPLICIDADE:         { area: "Prescrição", gravidade: "alta",  titulo: "Medicamento repetido na prescrição" },
  DUPLICIDADE_CLASSE:  { area: "Prescrição", gravidade: "media", titulo: "Dois medicamentos da mesma classe" },
  AINE_DENGUE:         { area: "Prescrição", gravidade: "alta",  titulo: "Anti-inflamatório com suspeita de dengue" },
  ATB_VIRAL:           { area: "Prescrição", gravidade: "media", titulo: "Antibiótico com diagnóstico geralmente viral" },
  CORTICOIDE_VARICELA: { area: "Prescrição", gravidade: "media", titulo: "Corticoide em varicela" },
  SEM_ESTOQUE:         { area: "Prescrição", gravidade: "media", titulo: "Medicamento sem estoque na farmácia" },
  FORA_FORMULARIO:     { area: "Prescrição", gravidade: "baixa", titulo: "Medicamento fora do formulário conferido" },
  SEM_DIAGNOSTICO:     { area: "Prescrição", gravidade: "baixa", titulo: "Prescrição sem diagnóstico" },

  // Administração de medicamentos (enfermagem)
  SEM_PRESCRICAO:      { area: "Medicação", gravidade: "alta",  titulo: "Criança sem prescrição registrada" },
  NAO_PRESCRITO:       { area: "Medicação", gravidade: "alta",  titulo: "Medicamento que não está na prescrição" },
  DOSE_DIVERGENTE:     { area: "Medicação", gravidade: "alta",  titulo: "Dose diferente da prescrita" },
  INTERVALO_CURTO:     { area: "Medicação", gravidade: "alta",  titulo: "Intervalo menor que o prescrito" },
  LIMITE_DIARIO:       { area: "Medicação", gravidade: "alta",  titulo: "Mais doses que o prescrito no dia" },
  PRESCRICAO_ANTIGA:   { area: "Medicação", gravidade: "media", titulo: "Prescrição com mais de 7 dias" },

  // Dados do paciente
  NASCIMENTO_INVALIDO: { area: "Cadastro", gravidade: "alta",  titulo: "Data de nascimento inválida" },
  ADULTO_PEDIATRICO:   { area: "Cadastro", gravidade: "media", titulo: "Paciente com 18 anos ou mais" },
  CPF_INVALIDO:        { area: "Cadastro", gravidade: "media", titulo: "CPF inválido" },
  CPF_REPETIDO:        { area: "Cadastro", gravidade: "alta",  titulo: "CPF repetido em outro cadastro" },
  POSSIVEL_DUPLICIDADE:{ area: "Cadastro", gravidade: "media", titulo: "Possível cadastro duplicado" },
  TELEFONE_INVALIDO:   { area: "Cadastro", gravidade: "baixa", titulo: "Telefone do responsável incompleto" },
  PESO_IMPLAUSIVEL:    { area: "Triagem",  gravidade: "media", titulo: "Peso incomum para a idade" },
  RISCO_SUBCLASSIFICADO:{ area: "Triagem", gravidade: "alta",  titulo: "Classificação menor que a calculada" },

  // Operação
  ESPERA_ACIMA_ALVO:   { area: "Operação", gravidade: "media", titulo: "Espera acima do tempo-alvo" },
  ENCAMINHAMENTO_URGENTE_PARADO: { area: "Operação", gravidade: "alta",  titulo: "Encaminhamento urgente sem atendimento" },
  ENCAMINHAMENTO_ATRASADO:       { area: "Operação", gravidade: "media", titulo: "Encaminhamento pendente há mais de 24 h" },
  DOR_ALTA_RECENTE:    { area: "Operação", gravidade: "media", titulo: "Dor forte registrada pela criança" },
  RISCO_PSIQUIATRICO:  { area: "Operação", gravidade: "alta",  titulo: "Alerta de risco na avaliação psiquiátrica" },
  ESTOQUE_ZERADO:      { area: "Operação", gravidade: "media", titulo: "Medicamento zerado no estoque" },
  ESTOQUE_BAIXO:       { area: "Operação", gravidade: "baixa", titulo: "Medicamento com estoque baixo" }
};

// Monta um alerta com título e gravidade vindos do catálogo.
function alerta(codigo, detalhe, extra = {}) {
  const regra = REGRAS[codigo];
  return {
    codigo,
    area: regra.area,
    gravidade: extra.gravidade || regra.gravidade,
    titulo: regra.titulo,
    detalhe,
    ...extra
  };
}

// Alta primeiro, depois média e baixa.
const porGravidade = (a, b) => GRAVIDADES[a.gravidade] - GRAVIDADES[b.gravidade];

/* ---------- Medicamentos: classe e termos de alergia ---------- */
const MEDICAMENTOS = {
  paracetamol:  { classe: "analgésico/antitérmico", termos: ["paracetamol", "acetaminofeno", "tylenol"] },
  dipirona:     { classe: "analgésico/antitérmico", termos: ["dipirona", "metamizol", "novalgina"] },
  ibuprofeno:   { classe: "anti-inflamatório",      termos: ["ibuprofeno", "alivium", "aine", "anti-inflamatorio", "anti inflamatorio"] },
  amoxicilina:  { classe: "antibiótico",            termos: ["amoxicilina", "penicilina", "ampicilina", "betalactamico", "beta-lactamico"] },
  azitromicina: { classe: "antibiótico",            termos: ["azitromicina", "macrolideo", "eritromicina", "claritromicina"] },
  ondansetrona: { classe: "antiemético",            termos: ["ondansetrona", "vonau"] },
  prednisolona: { classe: "corticoide",             termos: ["prednisolona", "prednisona", "corticoide", "corticosteroide"] }
};

/* ---------- Texto ---------- */
// Minúsculas e sem acento, para comparar textos digitados à mão.
const normalizar = texto => String(texto ?? "")
  .normalize("NFD")
  .replace(/[\u0300-\u036f]/g, "")
  .toLowerCase()
  .trim();

// "Nega alergias", "Nenhuma", "Sem alergia"... = não tem alergia.
const NEGACAO = /^(nega|nenhum|nao |sem |n\/a|-|ausente)/;

// O texto de alergia da triagem cita este medicamento (ou a classe dele)?
function alergiaConflita(textoAlergia, idMedicamento) {
  const alergia = normalizar(textoAlergia);
  if (!alergia || NEGACAO.test(alergia)) return null;

  const dados = MEDICAMENTOS[idMedicamento];
  if (!dados) return null;

  return dados.termos.find(termo => alergia.includes(termo)) || null;
}

module.exports = { REGRAS, GRAVIDADES, MEDICAMENTOS, alerta, porGravidade, normalizar, alergiaConflita };
