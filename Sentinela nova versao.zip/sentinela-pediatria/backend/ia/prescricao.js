/* =====================================================
   ia/prescricao.js — conferência de prescrições.
   Recebe a prescrição e devolve uma lista de alertas.
   Nunca bloqueia sozinha: quem decide é o médico.
   ===================================================== */

const Ped = require("../../frontend/js/pediatria.js");
const { alerta, normalizar, alergiaConflita, MEDICAMENTOS } = require("./catalogo");

const numero = valor => {
  const n = Number(String(valor ?? "").replace(",", "."));
  return valor === "" || valor == null || !isFinite(n) ? null : n;
};

// Acha o medicamento no formulário (pelo id ou pelo começo do nome).
function formularioDe(item) {
  if (item.id) {
    const porId = Ped.FORM.find(f => f.id === item.id);
    if (porId) return porId;
  }
  const nome = normalizar(item.nome || item.texto);
  return Ped.FORM.find(f => nome.startsWith(normalizar(f.nome))) || null;
}

// Lê mg e mL de um item (campos novos ou, em registros antigos, do texto).
function lerDose(item) {
  const texto = String(item.texto || "");
  let mg = numero(item.mg);
  let ml = numero(item.ml);

  if (mg == null) {
    const achou = texto.match(/\(([\d.,]+)\s*mg\)/i);
    if (achou) mg = numero(achou[1]);
  }
  if (ml == null) {
    const achou = texto.match(/:\s*([\d.,]+)\s*mL/i);
    if (achou) ml = numero(achou[1]);
  }
  return { mg, ml };
}

const VIRAL = /resfriado|\bj00\b|j06|infeccao viral|b34|bronquiolite|j21|varicela|b01|dengue|a90|zika|chikungunya|gripe|virose/;
const DENGUE = /dengue|\ba90\b|\ba91\b/;
const VARICELA = /varicela|\bb01/;

function verificarPrescricao({ paciente, triagem, diagnostico, itens, estoque = [] }) {
  const alertas = [];
  const lista = (itens || []).filter(item => item && (item.nome || item.texto));
  if (!lista.length) return alertas;

  const idade = paciente ? Ped.idade(paciente.nascimento) : null;
  const meses = idade ? idade.meses : null;
  const peso = triagem && triagem.peso > 0 ? triagem.peso : null;
  const dx = normalizar(diagnostico);
  const comFormulario = [];

  if (!peso) {
    alertas.push(alerta("SEM_PESO", "Sem o peso da triagem não é possível conferir as doses. Confirme o peso antes de prescrever."));
  }
  if (!dx) {
    alertas.push(alerta("SEM_DIAGNOSTICO", "Informe o diagnóstico para que a prescrição possa ser conferida."));
  }

  for (const item of lista) {
    const f = formularioDe(item);
    const nome = item.nome || (f && f.nome) || "Medicamento";

    if (!f) {
      alertas.push(alerta("FORA_FORMULARIO", nome + ": não há faixa de dose cadastrada. Confira manualmente.", { item: nome }));
      continue;
    }
    comFormulario.push({ item, f });

    // Alergia informada na triagem.
    const termo = triagem ? alergiaConflita(triagem.alergia, f.id) : null;
    if (termo) {
      alertas.push(alerta("ALERGIA", `${f.nome}: a triagem registra alergia ("${termo}"). Alergia informada: ${triagem.alergia}.`, { item: f.nome }));
    }

    // Estoque.
    const naFarmacia = estoque.find(e => normalizar(e.nome).startsWith(normalizar(f.nome)));
    if (naFarmacia && naFarmacia.quantidade <= 0) {
      alertas.push(alerta("SEM_ESTOQUE", `${naFarmacia.nome} está zerado na farmácia.`, { item: f.nome }));
    }

    // Idade e peso mínimos.
    if ((f.minMeses && meses != null && meses < f.minMeses) || (f.minKg && peso && peso < f.minKg)) {
      alertas.push(alerta("IDADE_MINIMA", `${f.nome}: não recomendado abaixo de ${f.minMeses ? f.minMeses + " meses" : f.minKg + " kg"} (criança: ${idade ? idade.texto : "idade ?"}${peso ? ", " + peso + " kg" : ""}).`, { item: f.nome }));
    }

    const { mg, ml } = lerDose(item);
    if (mg == null) continue;

    // mg x mL: o arredondamento do mL pode mudar o mg em até meio décimo.
    if (ml != null && Math.abs(ml * f.conc - mg) > Math.max(0.06 * f.conc, 0.1 * mg)) {
      alertas.push(alerta("CONVERSAO_MG_ML", `${f.nome}: ${ml} mL de ${f.conc} mg/mL dá ${+(ml * f.conc).toFixed(1)} mg, mas a prescrição diz ${mg} mg.`, { item: f.nome }));
    }

    if (f.maxDose && mg > f.maxDose * 1.01) {
      alertas.push(alerta("DOSE_MAXIMA", `${f.nome}: ${mg} mg passa do máximo de ${f.maxDose} mg por administração.`, { item: f.nome }));
    }

    if (!peso) continue;

    const vezes = numero(item.vezes) || f.vezes;
    const porDose = mg / peso;
    const porDia = (mg * vezes) / peso;
    const valorFaixa = f.modo === "dia" ? porDia : porDose;
    const unidade = f.modo === "dia" ? "mg/kg/dia" : "mg/kg/dose";
    const texto = `${f.nome}: ${+valorFaixa.toFixed(2)} ${unidade} (faixa usual ${f.min}–${f.max}, peso ${peso} kg)`;

    // Tolerância de 5% para arredondamentos.
    if (valorFaixa > f.max * 1.05) alertas.push(alerta("DOSE_ACIMA", texto + ".", { item: f.nome }));
    else if (valorFaixa < f.min * 0.95) alertas.push(alerta("DOSE_ABAIXO", texto + ".", { item: f.nome }));

    if (f.maxDiaKg && porDia > f.maxDiaKg * 1.02) {
      alertas.push(alerta("DOSE_DIARIA", `${f.nome}: ${+porDia.toFixed(1)} mg/kg/dia passa do limite de ${f.maxDiaKg} mg/kg/dia.`, { item: f.nome }));
    }
  }

  // Repetidos e mesma classe.
  const porId = {};
  comFormulario.forEach(({ f }) => { porId[f.id] = (porId[f.id] || 0) + 1; });
  Object.entries(porId).filter(([, n]) => n > 1).forEach(([id]) => {
    alertas.push(alerta("DUPLICIDADE", `${Ped.FORM.find(f => f.id === id).nome} aparece ${porId[id]} vezes na prescrição.`));
  });

  const porClasse = {};
  Object.keys(porId).forEach(id => {
    const classe = MEDICAMENTOS[id] && MEDICAMENTOS[id].classe;
    if (classe) (porClasse[classe] = porClasse[classe] || []).push(Ped.FORM.find(f => f.id === id).nome);
  });
  Object.entries(porClasse).filter(([, nomes]) => nomes.length > 1).forEach(([classe, nomes]) => {
    alertas.push(alerta("DUPLICIDADE_CLASSE", `${nomes.join(" + ")} (${classe}). Confirme se a associação ou alternância é intencional.`));
  });

  // Diagnóstico x medicamento.
  const usa = id => !!porId[id];
  const usaAntibiotico = usa("amoxicilina") || usa("azitromicina");
  const sinaisDengue = triagem && (triagem.sinais || []).includes("dengue");

  if (usa("ibuprofeno") && (DENGUE.test(dx) || sinaisDengue)) {
    alertas.push(alerta("AINE_DENGUE", "Ibuprofeno prescrito com " + (DENGUE.test(dx) ? "diagnóstico de dengue" : "sinal de alarme de dengue na triagem") + ". Anti-inflamatórios costumam ser evitados na dengue.", { item: "Ibuprofeno" }));
  }
  if (usaAntibiotico && VIRAL.test(dx)) {
    alertas.push(alerta("ATB_VIRAL", `Antibiótico com o diagnóstico "${diagnostico}", que costuma ser viral. Confirme a indicação.`));
  }
  if (usa("prednisolona") && VARICELA.test(dx)) {
    alertas.push(alerta("CORTICOIDE_VARICELA", "Prednisolona com varicela: corticoide sistêmico geralmente é evitado. Confirme a indicação.", { item: "Prednisolona" }));
  }

  return alertas;
}

module.exports = { verificarPrescricao, formularioDe, lerDose, numero };
