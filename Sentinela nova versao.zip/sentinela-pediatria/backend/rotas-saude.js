/* =====================================================
   rotas-saude.js — saúde mental e enfermagem:
     • apoio psicológico aos familiares
     • acompanhamento emocional (linha do tempo da criança)
     • cuidados de enfermagem (com conferência da IA)
   ===================================================== */

const express = require("express");

const Ped = require("../frontend/js/pediatria.js");
const Hosp = require("../frontend/js/hospital.js");
const { ler, gravar } = require("./banco");
const { txt, num, bad, rota, novoId, inteiroEntre } = require("./util");
const { exigirTipo } = require("./auth");
const { buscarPaciente, textoIdade, ultimos } = require("./apoio");
const IA = require("./ia");
const { verificarAdministracao } = require("./ia/medicacao");
const { formularioDe } = require("./ia/prescricao");
const { porGravidade } = require("./ia/catalogo");
const { pode } = require("./ia/permissoes");

const router = express.Router();

const existe = (lista, id) => lista.some(item => item.id === id);
const daCrianca = req => item => !req.query.pacienteId || item.pacienteId === Number(req.query.pacienteId);

/* =====================================================
   APOIO PSICOLÓGICO AOS FAMILIARES
   Conteúdo sensível: só psicologia e psiquiatria.
   ===================================================== */
const soSaudeMental = exigirTipo("psicologia", "psiquiatria");

router.post("/familia/atendimento", soSaudeMental, rota((req, res) => {
  const b = req.body;
  const dados = ler();

  const paciente = buscarPaciente(dados, b.pacienteId);
  if (!paciente) return bad(res, "Selecione a criança.", 404);

  const familiar = txt(b.familiar);
  if (!familiar) return bad(res, "Informe o nome do familiar atendido.");
  if (!existe(Hosp.TIPOS_APOIO_FAMILIAR, txt(b.tipo))) return bad(res, "Selecione o tipo de apoio.");

  const resumo = txt(b.resumo);
  if (!resumo) return bad(res, "Escreva o resumo do atendimento.");

  const profissional = txt(b.profissional);
  const registro = txt(b.registro);
  if (!profissional || !registro) return bad(res, "Informe o profissional e o registro (CRP/CRM).");

  const estadoEmocional = inteiroEntre(b.estadoEmocional, 1, 5);
  const duracao = inteiroEntre(b.duracao, 1, 480);
  if (estadoEmocional === undefined) return bad(res, "Estado emocional inválido.");
  if (duracao === undefined) return bad(res, "Duração inválida (1 a 480 minutos).");

  const atendimento = {
    id: novoId(),
    pacienteId: paciente.id,
    paciente: paciente.nome,
    familiar,
    parentesco: txt(b.parentesco),
    tipo: txt(b.tipo),
    demanda: txt(b.demanda),
    resumo,
    estadoEmocional,
    duracao,
    seguimento: !!b.seguimento,
    profissional,
    registro,
    createdAt: new Date().toISOString()
  };
  dados.apoioFamiliar.push(atendimento);
  gravar(dados);

  res.status(201).json({ ...atendimento, avisarEquipe: estadoEmocional === 1 });
}));

router.get("/familia/atendimentos", soSaudeMental, rota((req, res) => {
  res.json(ultimos(ler().apoioFamiliar.filter(daCrianca(req)), req.query.limite, 20));
}));

/* =====================================================
   ACOMPANHAMENTO EMOCIONAL
   Une humor, sessões, avaliações, espaço sensorial e
   atividades numa linha do tempo. O texto dos registros
   clínicos só aparece para psicologia e psiquiatria.
   ===================================================== */
const media = lista => lista.length ? lista.reduce((s, n) => s + n, 0) / lista.length : null;

router.get("/acompanhamento/:id", exigirTipo("psicologia", "psiquiatria", "medico", "enfermagem"), rota((req, res) => {
  const dados = ler();
  const paciente = buscarPaciente(dados, req.params.id);
  if (!paciente) return bad(res, "Criança não encontrada.", 404);

  const detalhado = ["psicologia", "psiquiatria"].includes(req.sessao.tipo);
  const deste = item => item.pacienteId === paciente.id;
  const eventos = [];

  dados.sessoesPsicologia.filter(deste).forEach(s => eventos.push({
    quando: s.createdAt, tipo: "psicologia", icone: "💬", titulo: "Sessão de psicologia",
    humorAntes: s.humorAntes, humorDepois: s.humorDepois,
    texto: detalhado ? s.resumo : null, autor: detalhado ? s.profissional : null
  }));
  dados.avaliacoesPsiquiatria.filter(deste).forEach(a => eventos.push({
    quando: a.createdAt, tipo: "psiquiatria", icone: "🧠", titulo: "Avaliação psiquiátrica (risco " + a.nivelRisco + ")",
    alerta: a.alertaRisco, texto: detalhado ? a.queixa + " — Conduta: " + a.conduta : null, autor: detalhado ? a.profissional : null
  }));
  dados.sessoesSensorial.filter(deste).forEach(s => eventos.push({
    quando: s.createdAt, tipo: "sensorial", icone: "✨", titulo: "Espaço sensorial",
    humorAntes: s.humorAntes, humorDepois: s.humorDepois,
    texto: Hosp.nomeDe(Hosp.TOLERANCIA_SENSORIAL, s.tolerancia)
  }));
  dados.participacoes.filter(deste).filter(p => p.status === "realizada").forEach(p => eventos.push({
    quando: p.createdAt, tipo: "atividade", icone: p.icone, titulo: p.atividade,
    texto: p.reacao ? "Reação depois: " + p.reacao + "/5" : null
  }));
  dados.humores.filter(deste).forEach(h => eventos.push({
    quando: h.createdAt, tipo: "humor", icone: "🌈", titulo: "Check-in da criança",
    humor: h.humor, dor: h.dor, texto: h.nota || null
  }));

  eventos.sort((a, b) => new Date(b.quando) - new Date(a.quando));

  // Série de humor (do mais antigo ao mais novo) e tendência.
  const humores = dados.humores.filter(deste).filter(h => h.humor != null);
  const agora = Date.now();
  const ultimosDias = (de, ate) => humores
    .filter(h => agora - new Date(h.createdAt) >= de * 864e5 && agora - new Date(h.createdAt) < ate * 864e5)
    .map(h => h.humor);

  const recente = media(ultimosDias(0, 3));
  const anterior = media(ultimosDias(3, 7));
  let tendencia = "sem dados suficientes";
  if (recente != null && anterior != null) {
    const diferenca = recente - anterior;
    tendencia = diferenca >= 0.5 ? "melhorando" : diferenca <= -0.5 ? "piorando" : "estável";
  }

  const avaliacoes = dados.avaliacoesPsiquiatria.filter(deste);
  const ultimaAvaliacao = avaliacoes[avaliacoes.length - 1] || null;
  const ultimaDor = dados.humores.filter(deste).filter(h => h.dor != null).slice(-1)[0] || null;

  res.json({
    paciente: { id: paciente.id, nome: paciente.nome, idadeTexto: textoIdade(paciente), responsavel: paciente.responsavel },
    detalhado,
    resumo: {
      humorMedio7d: media(ultimosDias(0, 7)) == null ? null : +media(ultimosDias(0, 7)).toFixed(1),
      tendencia,
      ultimoHumor: humores.length ? humores[humores.length - 1].humor : null,
      ultimaDor: ultimaDor ? ultimaDor.dor : null,
      sessoes: dados.sessoesPsicologia.filter(deste).length,
      riscoAtual: ultimaAvaliacao ? ultimaAvaliacao.nivelRisco : null,
      alertaRisco: !!(ultimaAvaliacao && ultimaAvaliacao.alertaRisco),
      pendentes: dados.encaminhamentos.filter(e => e.pacienteId === paciente.id && e.status === "pendente")
        .map(e => ({ destino: e.destino, urgencia: e.urgencia }))
    },
    serieHumor: humores.slice(-30).map(h => ({ quando: h.createdAt, humor: h.humor })),
    eventos: eventos.slice(0, 60)
  });
}));

/* =====================================================
   ENFERMAGEM
   ===================================================== */
function lerSinais(b) {
  const sinais = {
    temperatura: num(b.temperatura), fc: num(b.fc), fr: num(b.fr), spo2: num(b.spo2), dor: inteiroEntre(b.dor, 0, 10)
  };
  if (sinais.temperatura != null && (sinais.temperatura < 30 || sinais.temperatura > 43)) return { erro: "Temperatura inválida." };
  if (sinais.spo2 != null && (sinais.spo2 < 30 || sinais.spo2 > 100)) return { erro: "SpO₂ inválida." };
  if (sinais.fc != null && (sinais.fc < 20 || sinais.fc > 300)) return { erro: "Frequência cardíaca inválida." };
  if (sinais.fr != null && (sinais.fr < 4 || sinais.fr > 120)) return { erro: "Frequência respiratória inválida." };
  if (sinais.dor === undefined) return { erro: "Dor inválida (0 a 10)." };
  return { sinais };
}

router.post("/enfermagem/registro", exigirTipo("enfermagem", "triagem", "medico", "admin"), rota((req, res) => {
  const b = req.body;
  const dados = ler();

  const paciente = buscarPaciente(dados, b.pacienteId);
  if (!paciente) return bad(res, "Selecione a criança.", 404);
  if (paciente.status === "encerrado") return bad(res, "Esta criança já recebeu alta.", 409);

  const tipo = txt(b.tipo);
  if (!existe(Hosp.TIPOS_ENFERMAGEM, tipo)) return bad(res, "Selecione o tipo de cuidado.");

  const profissional = txt(b.profissional);
  const registro = txt(b.registro);
  if (!profissional || !registro) return bad(res, "Informe o profissional e o registro (COREN).");

  const descricao = txt(b.descricao);
  const quando = b.quando ? new Date(b.quando) : new Date();
  if (isNaN(quando) || quando - Date.now() > 5 * 6e4) return bad(res, "Horário inválido (não pode ser no futuro).");

  const item = {
    id: novoId(), pacienteId: paciente.id, paciente: paciente.nome, tipo, descricao,
    quando: quando.toISOString(), profissional, registro, createdAt: new Date().toISOString()
  };

  let avisoRisco = null;

  if (tipo === "sinais") {
    const { sinais, erro } = lerSinais(b);
    if (erro) return bad(res, erro);
    if (Object.values(sinais).every(v => v == null)) return bad(res, "Informe ao menos um sinal vital.");
    Object.assign(item, sinais);

    const calculo = Ped.classificar({
      meses: (Ped.idade(paciente.nascimento) || { meses: 0 }).meses,
      temp: sinais.temperatura, fc: sinais.fc, fr: sinais.fr, spo2: sinais.spo2, sinais: []
    });
    item.risco = calculo.risco;
    if (Ped.ORD.indexOf(calculo.risco) >= Ped.ORD.indexOf("laranja")) {
      avisoRisco = { risco: calculo.risco, motivos: calculo.motivos };
    }
  } else if (tipo === "medicacao") {
    const medicamento = txt(b.medicamento);
    const doseMg = num(b.doseMg), doseMl = num(b.doseMl);
    if (!medicamento) return bad(res, "Informe o medicamento administrado.");
    if (doseMg == null && doseMl == null) return bad(res, "Informe a dose administrada (mg ou mL).");
    if ((doseMg != null && doseMg <= 0) || (doseMl != null && doseMl <= 0)) return bad(res, "A dose deve ser maior que zero.");

    const formulario = formularioDe({ nome: medicamento });
    Object.assign(item, { medicamento, medicamentoId: formulario ? formulario.id : null, doseMg, doseMl, via: txt(b.via) });

    // Conferência da Sentinela Intelligence (se o perfil tem essa permissão).
    const alertas = pode(req.sessao, "medicacao")
      ? verificarAdministracao(dados, { pacienteId: paciente.id, medicamento, doseMg, doseMl, quando: item.quando }).sort(porGravidade)
      : [];
    item.alertasIA = alertas;

    if (IA.temAlertaGrave(alertas)) {
      const graves = alertas.filter(a => a.gravidade === "alta");

      if (!b.ciente) {
        req.auditoriaExtra = { ia: true, paciente: paciente.nome, detalhe: `Administração de ${medicamento} barrada pela IA: ${graves.map(a => a.codigo).join(", ")}` };
        return res.status(409).json({
          erro: "A Sentinela Intelligence encontrou alerta(s) grave(s). Revise antes de registrar.",
          alertas, exigeCiencia: true
        });
      }

      const justificativa = txt(b.justificativa);
      if (justificativa.length < 5) return bad(res, "Escreva a justificativa para registrar mesmo com o alerta.");

      item.cienteIA = { por: req.sessao.usuario, justificativa, em: new Date().toISOString() };
      req.auditoriaExtra = { ia: true, paciente: paciente.nome, detalhe: `Administração de ${medicamento} registrada apesar de ${graves.map(a => a.codigo).join(", ")}. Justificativa: ${justificativa}` };
    }
  } else if (!descricao) {
    return bad(res, "Descreva o cuidado realizado.");
  }

  dados.cuidadosEnfermagem.push(item);
  gravar(dados);

  res.status(201).json({ ...item, avisoRisco });
}));

router.get("/enfermagem/registros", exigirTipo("enfermagem", "medico", "triagem", "admin"), rota((req, res) => {
  const tipo = txt(req.query.tipo);
  const lista = ler().cuidadosEnfermagem.filter(daCrianca(req)).filter(r => !tipo || r.tipo === tipo);
  res.json(ultimos(lista, req.query.limite, 30));
}));

module.exports = router;
