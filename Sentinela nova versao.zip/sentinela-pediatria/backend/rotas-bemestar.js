/* =====================================================
   rotas-bemestar.js — rotas do cuidado emocional:
     • lista de pacientes ativos
     • humor e dor (Cantinho da criança)
     • encaminhamentos (pediatra -> psicologia/psiquiatria)
     • sessões de psicologia
     • avaliações de psiquiatria infantil
     • atividades de bem-estar (brinquedoteca etc.)
     • resumo para o painel do administrador
   ===================================================== */

const express = require("express");

const Bem = require("../frontend/js/bemestar.js");
const { ler, gravar } = require("./banco");
const { txt, bad, rota, novoId, inteiroEntre } = require("./util");
const { exigirTipo } = require("./auth");

// Prontuário de saúde mental: só psicologia e psiquiatria leem e gravam.
const soSaudeMental = exigirTipo("psicologia", "psiquiatria");

const router = express.Router();

/* ---------- Funções de apoio (ficam em apoio.js) ---------- */
const {
  buscarPaciente, textoIdade, PESO_URGENCIA,
  criarEncaminhamento, concluirEncaminhamentos, ultimos
} = require("./apoio");

/* =====================================================
   PACIENTES (dados mínimos, sem CPF nem telefone)
   ===================================================== */
router.get("/pacientes", rota((req, res) => {
  const dados = ler();
  const somenteAtivos = req.query.ativos === "1";

  const lista = dados.pacientes
    .filter(p => !somenteAtivos || p.status !== "encerrado")
    .map(p => ({
      id: p.id,
      nome: p.nome,
      nascimento: p.nascimento,
      idadeTexto: textoIdade(p),
      responsavel: p.responsavel,
      status: p.status
    }))
    .sort((a, b) => a.nome.localeCompare(b.nome, "pt-BR"));

  res.json(lista);
}));

/* =====================================================
   HUMOR E DOR (Cantinho da criança)
   ===================================================== */
router.post("/humor", rota((req, res) => {
  const b = req.body;
  const dados = ler();

  const paciente = buscarPaciente(dados, b.pacienteId);
  if (!paciente) return bad(res, "Paciente não encontrado.", 404);

  const humor = inteiroEntre(b.humor, 1, 5);
  const dor = inteiroEntre(b.dor, 0, 10);
  if (humor === undefined) return bad(res, "Humor inválido (use 1 a 5).");
  if (dor === undefined) return bad(res, "Dor inválida (use 0 a 10).");
  if (humor === null && dor === null) return bad(res, "Informe o humor ou a dor.");

  const registro = {
    id: novoId(),
    pacienteId: paciente.id,
    paciente: paciente.nome,
    humor,
    dor,
    nota: txt(b.nota),
    origem: txt(b.origem) || "cantinho",
    createdAt: new Date().toISOString()
  };
  dados.humores.push(registro);
  gravar(dados);

  res.status(201).json({
    ...registro,
    avisarEquipe: dor !== null && dor >= 7
  });
}));

router.get("/humores", rota((req, res) => {
  let lista = ler().humores;

  if (req.query.pacienteId) {
    lista = lista.filter(h => h.pacienteId === Number(req.query.pacienteId));
  }
  res.json(ultimos(lista, req.query.limite, 20));
}));

/* =====================================================
   ENCAMINHAMENTOS
   ===================================================== */
router.post("/encaminhamento", rota((req, res) => {
  const b = req.body;
  const dados = ler();

  const paciente = buscarPaciente(dados, b.pacienteId);
  if (!paciente) return bad(res, "Paciente não encontrado.", 404);

  const destino = txt(b.destino);
  if (!Bem.DESTINOS.includes(destino)) return bad(res, "Destino inválido.");

  const urgencia = txt(b.urgencia) || "rotina";
  if (!Bem.URGENCIAS.some(u => u.id === urgencia)) return bad(res, "Urgência inválida.");

  const motivo = txt(b.motivo);
  if (!motivo) return bad(res, "Informe o motivo do encaminhamento.");

  const { registro, jaExistia } = criarEncaminhamento(
    dados, paciente, destino, motivo, urgencia, txt(b.origem) || req.sessao.usuario
  );
  gravar(dados);

  res.status(jaExistia ? 200 : 201).json({ ...registro, jaExistia });
}));

router.get("/encaminhamentos", rota((req, res) => {
  const dados = ler();
  const { destino, status } = req.query;

  const lista = dados.encaminhamentos
    .filter(e => !destino || e.destino === destino)
    .filter(e => !status || e.status === status)
    .map(e => {
      const paciente = buscarPaciente(dados, e.pacienteId);
      return { ...e, idadeTexto: paciente ? textoIdade(paciente) : "" };
    })
    .sort((a, b) =>
      (PESO_URGENCIA[a.urgencia] ?? 2) - (PESO_URGENCIA[b.urgencia] ?? 2) ||
      new Date(a.createdAt) - new Date(b.createdAt)
    );

  res.json(lista);
}));

// Dispensar (cancelar) um encaminhamento pendente.
router.put("/encaminhamentos/:id", rota((req, res) => {
  const dados = ler();
  const encaminhamento = dados.encaminhamentos.find(e => e.id === Number(req.params.id));
  if (!encaminhamento) return bad(res, "Encaminhamento não encontrado.", 404);

  if (txt(req.body.status) !== "cancelado") return bad(res, "Status inválido.");
  if (encaminhamento.status !== "pendente") return bad(res, "Este encaminhamento já foi encerrado.", 409);

  encaminhamento.status = "cancelado";
  encaminhamento.atendidoEm = new Date().toISOString();
  gravar(dados);

  res.json(encaminhamento);
}));

/* =====================================================
   PSICOLOGIA — sessões
   ===================================================== */
router.post("/psicologia/sessao", soSaudeMental, rota((req, res) => {
  const b = req.body;
  const dados = ler();

  const paciente = buscarPaciente(dados, b.pacienteId);
  if (!paciente) return bad(res, "Selecione a criança atendida.", 404);

  const tipo = txt(b.tipo);
  if (!Bem.TIPOS_SESSAO.some(t => t.id === tipo)) return bad(res, "Selecione o tipo de atendimento.");

  const resumo = txt(b.resumo);
  if (!resumo) return bad(res, "Escreva o resumo do atendimento.");

  const profissional = txt(b.profissional);
  const registroProfissional = txt(b.registro);
  if (!profissional || !registroProfissional) {
    return bad(res, "Informe o profissional e o registro (CRP).");
  }

  const humorAntes = inteiroEntre(b.humorAntes, 1, 5);
  const humorDepois = inteiroEntre(b.humorDepois, 1, 5);
  const duracao = inteiroEntre(b.duracao, 1, 480);
  if (humorAntes === undefined || humorDepois === undefined) return bad(res, "Humor inválido.");
  if (duracao === undefined) return bad(res, "Duração inválida (1 a 480 minutos).");

  const tecnicas = (Array.isArray(b.tecnicas) ? b.tecnicas : [])
    .filter(id => Bem.TECNICAS.some(t => t.id === id));

  const sessao = {
    id: novoId(),
    pacienteId: paciente.id,
    paciente: paciente.nome,
    tipo,
    humorAntes,
    humorDepois,
    duracao,
    tecnicas,
    resumo,
    sugerirPsiquiatria: !!b.sugerirPsiquiatria,
    profissional,
    registro: registroProfissional,
    createdAt: new Date().toISOString()
  };
  dados.sessoesPsicologia.push(sessao);

  // A criança foi atendida: fecha os pedidos pendentes para a psicologia.
  concluirEncaminhamentos(dados, paciente.id, "psicologia");

  // Se a psicologia sugeriu avaliação psiquiátrica, já abre o encaminhamento.
  if (sessao.sugerirPsiquiatria) {
    criarEncaminhamento(
      dados, paciente, "psiquiatria",
      txt(b.motivoPsiquiatria) || "Avaliação sugerida pela psicologia após atendimento.",
      "prioritaria", "psicologia"
    );
  }

  gravar(dados);
  res.status(201).json(sessao);
}));

router.get("/psicologia/sessoes", soSaudeMental, rota((req, res) => {
  let lista = ler().sessoesPsicologia;

  if (req.query.pacienteId) {
    lista = lista.filter(s => s.pacienteId === Number(req.query.pacienteId));
  }
  res.json(ultimos(lista, req.query.limite, 20));
}));

/* =====================================================
   PSIQUIATRIA INFANTIL — avaliações
   ===================================================== */
router.post("/psiquiatria/avaliacao", soSaudeMental, rota((req, res) => {
  const b = req.body;
  const dados = ler();

  const paciente = buscarPaciente(dados, b.pacienteId);
  if (!paciente) return bad(res, "Selecione a criança avaliada.", 404);

  const queixa = txt(b.queixa);
  if (!queixa) return bad(res, "Descreva o motivo da avaliação.");

  const nivelRisco = txt(b.nivelRisco);
  if (!Bem.RISCOS.includes(nivelRisco)) return bad(res, "Selecione o nível de risco.");

  const conduta = txt(b.conduta);
  if (!conduta) return bad(res, "Selecione a conduta.");

  const profissional = txt(b.profissional);
  const registroProfissional = txt(b.registro);
  if (!profissional || !registroProfissional) {
    return bad(res, "Informe o profissional e o registro (CRM).");
  }

  const sinais = (Array.isArray(b.sinais) ? b.sinais : [])
    .filter(id => Bem.SINAIS_PSIQUIATRIA.some(s => s.id === id));

  // Sinais críticos ou risco alto = a equipe precisa agir agora.
  const temSinalCritico = sinais.some(id =>
    Bem.SINAIS_PSIQUIATRIA.find(s => s.id === id).critico
  );
  const alertaRisco = nivelRisco === "alto" || temSinalCritico;

  const avaliacao = {
    id: novoId(),
    pacienteId: paciente.id,
    paciente: paciente.nome,
    queixa,
    sinais,
    nivelRisco,
    alertaRisco,
    conduta,
    retorno: txt(b.retorno),
    observacoes: txt(b.observacoes),
    profissional,
    registro: registroProfissional,
    createdAt: new Date().toISOString()
  };
  dados.avaliacoesPsiquiatria.push(avaliacao);
  concluirEncaminhamentos(dados, paciente.id, "psiquiatria");

  gravar(dados);
  res.status(201).json(avaliacao);
}));

router.get("/psiquiatria/avaliacoes", soSaudeMental, rota((req, res) => {
  let lista = ler().avaliacoesPsiquiatria;

  if (req.query.pacienteId) {
    lista = lista.filter(a => a.pacienteId === Number(req.query.pacienteId));
  }
  res.json(ultimos(lista, req.query.limite, 20));
}));

/* =====================================================
   ATIVIDADES DE BEM-ESTAR (agenda)
   ===================================================== */
router.post("/atividades/participacao", rota((req, res) => {
  const b = req.body;
  const dados = ler();

  const paciente = buscarPaciente(dados, b.pacienteId);
  if (!paciente) return bad(res, "Selecione a criança.", 404);

  const atividade = Bem.ATIVIDADES.find(a => a.id === txt(b.atividadeId));
  if (!atividade) return bad(res, "Atividade inválida.");

  const data = txt(b.data) || new Date().toISOString().slice(0, 10);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(data)) return bad(res, "Data inválida.");

  const participacao = {
    id: novoId(),
    pacienteId: paciente.id,
    paciente: paciente.nome,
    atividadeId: atividade.id,
    atividade: atividade.nome,
    icone: atividade.icone,
    data,
    horario: txt(b.horario),
    observacao: txt(b.observacao),
    profissional: txt(b.profissional),
    status: "agendada",
    reacao: null,
    createdAt: new Date().toISOString()
  };
  dados.participacoes.push(participacao);
  gravar(dados);

  res.status(201).json(participacao);
}));

router.get("/atividades/participacoes", rota((req, res) => {
  const data = txt(req.query.data);

  const lista = ler().participacoes
    .filter(p => !data || p.data === data)
    .sort((a, b) => (a.horario || "99:99").localeCompare(b.horario || "99:99"));

  res.json(lista);
}));

// Marca como realizada (com a reação da criança) ou cancelada.
router.put("/atividades/participacoes/:id", rota((req, res) => {
  const dados = ler();
  const participacao = dados.participacoes.find(p => p.id === Number(req.params.id));
  if (!participacao) return bad(res, "Participação não encontrada.", 404);

  const status = txt(req.body.status);
  if (!["realizada", "cancelada"].includes(status)) return bad(res, "Status inválido.");
  if (participacao.status !== "agendada") return bad(res, "Esta atividade já foi encerrada.", 409);

  const reacao = inteiroEntre(req.body.reacao, 1, 5);
  if (reacao === undefined) return bad(res, "Reação inválida.");

  participacao.status = status;
  participacao.reacao = status === "realizada" ? reacao : null;
  gravar(dados);

  res.json(participacao);
}));

/* =====================================================
   RESUMO DO PAINEL ADMINISTRATIVO
   "?desde=" = início do dia no horário do navegador (ISO).
   ===================================================== */
router.get("/resumo", rota((req, res) => {
  const dados = ler();

  const desdeInformado = new Date(req.query.desde);
  const desde = isNaN(desdeInformado) ? new Date(Date.now() - 864e5) : desdeInformado;
  const hoje = item => new Date(item.createdAt) >= desde;

  const ativos = dados.pacientes.filter(p => p.status !== "encerrado");
  const contar = status => dados.pacientes.filter(p => p.status === status).length;

  const pendentes = dados.encaminhamentos.filter(e => e.status === "pendente");
  const humoresHoje = dados.humores.filter(hoje);
  const comHumor = humoresHoje.filter(h => h.humor !== null);

  const humorMedio = comHumor.length
    ? +(comHumor.reduce((soma, h) => soma + h.humor, 0) / comHumor.length).toFixed(1)
    : null;

  // Crianças que precisam de um olhar: dor forte ou humor "muito triste".
  const alertas = humoresHoje
    .filter(h => (h.dor !== null && h.dor >= 7) || h.humor === 1)
    .slice(-5)
    .reverse()
    .map(h => ({ paciente: h.paciente, humor: h.humor, dor: h.dor, createdAt: h.createdAt }));

  const estoqueAtencao = dados.estoque
    .filter(i => i.quantidade < 10)
    .map(i => ({ nome: i.nome, quantidade: i.quantidade }));

  res.json({
    pacientes: {
      ativos: ativos.length,
      aguardandoTriagem: contar("triagem"),
      aguardandoMedico: contar("aguardando_medico"),
      aguardandoAlta: contar("aguardando_alta")
    },
    hoje: {
      cadastros: dados.pacientes.filter(hoje).length,
      consultas: dados.consultas.filter(hoje).length,
      altas: dados.altas.filter(hoje).length,
      sessoesPsicologia: dados.sessoesPsicologia.filter(hoje).length,
      avaliacoesPsiquiatria: dados.avaliacoesPsiquiatria.filter(hoje).length,
      checkins: humoresHoje.length
    },
    emocional: {
      pendentesPsicologia: pendentes.filter(e => e.destino === "psicologia").length,
      pendentesPsiquiatria: pendentes.filter(e => e.destino === "psiquiatria").length,
      urgentes: pendentes.filter(e => e.urgencia === "urgente").length,
      humorMedio,
      alertas
    },
    farmacia: {
      baixo: estoqueAtencao.filter(i => i.quantidade > 0).length,
      zerado: estoqueAtencao.filter(i => i.quantidade <= 0).length,
      itens: estoqueAtencao
    },
    usuarios: dados.usuarios.length
  });
}));

module.exports = router;
