/* =====================================================
   auth.js — sessão assinada (token) e proteção das rotas.

   Como funciona:
     1. No login o servidor devolve um token assinado.
     2. O navegador envia o token em toda requisição
        (cabeçalho Authorization: Bearer ...).
     3. O servidor confere a assinatura e a validade, e
        descobre quem é a pessoa (req.sessao).

   Chave de assinatura: variável SESSION_SECRET. Sem ela,
   uma chave aleatória é criada e guardada no db.json.
   Na Vercel, defina SESSION_SECRET (o disco é temporário).
   ===================================================== */

const crypto = require("crypto");
const { ler, gravar } = require("./banco");
const { bad } = require("./util");

const VALIDADE_HORAS = 12;

// Rotas que funcionam sem login (a TV da recepção não tem sessão).
const PUBLICAS = new Set(["/login", "/admin/acesso", "/tv-dados"]);

/* ---------- Chave de assinatura ---------- */
let chaveEmMemoria = null;

function chave() {
  if (process.env.SESSION_SECRET) return process.env.SESSION_SECRET;
  if (chaveEmMemoria) return chaveEmMemoria;

  const dados = ler();
  if (!dados.config.segredo) {
    dados.config.segredo = crypto.randomBytes(32).toString("hex");
    gravar(dados);
  }
  chaveEmMemoria = dados.config.segredo;
  return chaveEmMemoria;
}

const assinar = texto => crypto.createHmac("sha256", chave()).update(texto).digest("base64url");

/* ---------- Emitir e conferir token ---------- */

// mestre = entrou pela senha administrativa (não é um usuário cadastrado).
function emitirToken({ usuario, tipo, mestre = false }) {
  const corpo = Buffer.from(JSON.stringify({
    u: usuario,
    t: tipo,
    m: mestre,
    exp: Date.now() + VALIDADE_HORAS * 36e5
  })).toString("base64url");

  return corpo + "." + assinar(corpo);
}

function lerToken(token) {
  const [corpo, assinatura] = String(token || "").split(".");
  if (!corpo || !assinatura) return null;

  const esperada = Buffer.from(assinar(corpo));
  const recebida = Buffer.from(assinatura);
  if (esperada.length !== recebida.length || !crypto.timingSafeEqual(esperada, recebida)) return null;

  try {
    const dados = JSON.parse(Buffer.from(corpo, "base64url").toString("utf8"));
    return dados.exp > Date.now() ? dados : null;
  } catch {
    return null;
  }
}

/* ---------- Middleware: exige login em tudo, menos nas rotas públicas ---------- */
function autenticar(req, res, next) {
  const caminho = req.path || req.originalUrl.split("?")[0];
  if (PUBLICAS.has(caminho)) return next();

  const cabecalho = req.headers.authorization || "";
  const sessao = lerToken(cabecalho.startsWith("Bearer ") ? cabecalho.slice(7) : "");
  if (!sessao) return bad(res, "Sessão expirada. Entre novamente.", 401);

  // Confere se a conta ainda existe e usa o setor atual (se mudou, vale o novo).
  if (sessao.m) {
    req.sessao = { usuario: sessao.u, tipo: "admin", mestre: true };
    return next();
  }

  const conta = ler().usuarios.find(u => u.usuario === sessao.u);
  if (!conta) return bad(res, "Esta conta não existe mais.", 401);

  req.sessao = { usuario: conta.usuario, tipo: conta.tipo, mestre: false, iaPermissoes: conta.iaPermissoes };
  next();
}

/* ---------- Middleware: limita uma rota a certos setores ---------- */
//   router.get("/algo", exigirTipo("admin"), (req, res) => ...)
const exigirTipo = (...tipos) => (req, res, next) => {
  if (!req.sessao || !tipos.includes(req.sessao.tipo)) {
    return bad(res, "Você não tem permissão para esta ação.", 403);
  }
  next();
};

module.exports = { emitirToken, lerToken, autenticar, exigirTipo };
