/* =====================================================
   apoio.js — funções compartilhadas pelos arquivos de rotas
   (pacientes, encaminhamentos, datas e listas).
   ===================================================== */

const Ped = require("../frontend/js/pediatria.js");
const { novoId } = require("./util");

/* ---------- Pacientes ---------- */

function buscarPaciente(dados, id) {
  return dados.pacientes.find(p => p.id === Number(id));
}

function textoIdade(paciente) {
  const idade = Ped.idade(paciente.nascimento);
  return idade ? idade.texto : "";
}

// Última triagem da criança (tem peso, alergia e sinais).
function ultimaTriagem(dados, pacienteId) {
  return dados.triagens
    .filter(t => Number(t.pacienteId) === Number(pacienteId))
    .slice(-1)[0] || null;
}

/* ---------- Encaminhamentos entre profissionais ---------- */

// Mais urgente primeiro; em empate, quem chegou antes.
const PESO_URGENCIA = { urgente: 0, prioritaria: 1, rotina: 2 };

// Cria um encaminhamento. Se já existir um pendente para a mesma
// criança e o mesmo destino, devolve o existente (sem duplicar).
function criarEncaminhamento(dados, paciente, destino, motivo, urgencia, origem) {
  const existente = dados.encaminhamentos.find(e =>
    e.pacienteId === paciente.id && e.destino === destino && e.status === "pendente"
  );
  if (existente) {
    return { registro: existente, jaExistia: true };
  }

  const registro = {
    id: novoId(),
    pacienteId: paciente.id,
    paciente: paciente.nome,
    destino,
    motivo,
    urgencia,
    origem,
    status: "pendente",
    createdAt: new Date().toISOString()
  };
  dados.encaminhamentos.push(registro);
  return { registro, jaExistia: false };
}

// Marca como "atendido" os encaminhamentos pendentes da criança.
function concluirEncaminhamentos(dados, pacienteId, destino) {
  dados.encaminhamentos
    .filter(e => e.pacienteId === pacienteId && e.destino === destino && e.status === "pendente")
    .forEach(e => {
      e.status = "atendido";
      e.atendidoEm = new Date().toISOString();
    });
}

/* ---------- Listas e datas ---------- */

// Últimos itens primeiro, respeitando "?limite=" (máximo 100).
function ultimos(lista, limiteInformado, padrao) {
  const limite = Math.min(Number(limiteInformado) || padrao, 100);
  return lista.slice().reverse().slice(0, limite);
}

// Data de hoje (AAAA-MM-DD) no horário do servidor.
const hojeISO = () => new Date().toISOString().slice(0, 10);

// "AAAA-MM-DD" válido?
const dataValida = texto => /^\d{4}-\d{2}-\d{2}$/.test(texto) && !isNaN(new Date(texto + "T00:00:00"));

// "HH:MM" válido?
const horaValida = texto => /^([01]\d|2[0-3]):[0-5]\d$/.test(texto);

// "HH:MM" -> minutos desde meia-noite.
const minutos = hora => Number(hora.slice(0, 2)) * 60 + Number(hora.slice(3, 5));

/* ---------- Reservas de sala ---------- */

// Procura uma reserva ativa que se sobreponha ao horário pedido.
function conflitoReserva(dados, salaId, data, inicio, fim, ignorarId) {
  return dados.reservas.find(r =>
    r.status === "ativa" && r.salaId === salaId && r.data === data && r.id !== ignorarId &&
    minutos(inicio) < minutos(r.fim) && minutos(fim) > minutos(r.inicio)
  ) || null;
}

module.exports = {
  conflitoReserva,
  buscarPaciente, textoIdade, ultimaTriagem,
  PESO_URGENCIA, criarEncaminhamento, concluirEncaminhamentos,
  ultimos, hojeISO, dataValida, horaValida, minutos
};
