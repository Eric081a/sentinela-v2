/* =====================================================
   pediatria.js — regras pediátricas compartilhadas
   (usado pelo servidor e pelo navegador).

   ATENÇÃO: valores de referência (PALS/AIDPI/Manchester/bulas).
   Validar com o protocolo do hospital.
   ===================================================== */

(function (raiz, fabrica) {
  if (typeof module === "object" && module.exports) {
    module.exports = fabrica();
  } else {
    raiz.Pediatria = fabrica();
  }
})(this, function () {

  /* ---------- Cores de risco, da menos grave à mais grave ---------- */
  const ORD = ["azul", "verde", "amarelo", "laranja", "vermelho"];

  /* ---------- Tempo-alvo de atendimento (minutos, protocolo Manchester) ---------- */
  const ALVO = { vermelho: 0, laranja: 10, amarelo: 60, verde: 120, azul: 240 };

  /* ---------- Sinais de alerta: chave -> [cor mínima, descrição] ---------- */
  const SINAIS = {
    // Vermelho
    inconsciente: ["vermelho", "Inconsciente / não responde"],
    convulsao: ["vermelho", "Convulsão em andamento"],
    resp_grave: ["vermelho", "Desconforto respiratório grave (tiragem, gemência, apneia)"],
    cianose: ["vermelho", "Cianose"],
    choque: ["vermelho", "Sinais de choque (pele fria, pulso fraco, enchimento capilar > 3 s)"],

    // Laranja
    letargia: ["laranja", "Letargia / prostração / irritabilidade extrema"],
    petequias: ["laranja", "Petéquias / manchas que não desaparecem à compressão"],
    rigidez: ["laranja", "Rigidez de nuca"],
    desidratacao: ["laranja", "Sinais de desidratação (olhos fundos, sem lágrimas, sem urina há +8 h)"],
    recusa: ["laranja", "Recusa de líquidos / não consegue mamar"],
    dengue: ["laranja", "Sinal de alarme de dengue (dor abdominal intensa, sangramento de mucosa, vômitos persistentes)"],
    convulsao24: ["laranja", "Convulsão nas últimas 24 h"],

    // Amarelo
    vomitos: ["amarelo", "Vômitos repetidos"],
    dor: ["amarelo", "Dor intensa"]
  };

  /* ---------- Limites por idade: [até quantos meses, FC máxima, FR máxima] ---------- */
  const FAIXAS = [
    [1,   205, 60],
    [12,  180, 50],
    [36,  140, 40],
    [72,  120, 40],
    [144, 118, 25],
    [1e5, 100, 20]
  ];

  /* =====================================================
     IDADE a partir da data de nascimento
     Devolve { meses, texto } ou null se a data for inválida.
     ===================================================== */
  function idade(nascimento, referencia = new Date()) {
    const nasc = new Date(nascimento);
    if (isNaN(nasc) || nasc > referencia) return null;

    // Meses completos entre as duas datas.
    let meses =
      (referencia.getFullYear() - nasc.getFullYear()) * 12 +
      referencia.getMonth() - nasc.getMonth();
    if (referencia.getDate() < nasc.getDate()) meses--;

    const anos = Math.floor(meses / 12);
    const mesesRestantes = meses % 12;
    const dias = Math.floor((referencia - nasc) / 864e5);

    let texto;
    if (meses < 1) {
      texto = dias + (dias === 1 ? " dia" : " dias");
    } else if (meses < 24) {
      texto = meses + (meses === 1 ? " mês" : " meses");
    } else {
      texto = anos + " anos" + (mesesRestantes ? " e " + mesesRestantes + " m" : "");
    }

    return { meses, texto };
  }

  /* =====================================================
     CLASSIFICAÇÃO DE RISCO
     Recebe { meses, temp, fc, fr, spo2, sinais } e devolve
     { risco, motivos, alvoMin }.
     ===================================================== */
  function classificar(dados) {
    const motivos = [];
    let nivel = 1; // posição em ORD (começa no verde)

    // Registra um motivo e sobe o nível se a cor for mais grave.
    const subir = (cor, motivo) => {
      motivos.push(motivo);
      nivel = Math.max(nivel, ORD.indexOf(cor));
    };

    const meses = dados.meses || 0;
    const [, fcMax, frMax] = FAIXAS.find(faixa => meses < faixa[0]);
    const preenchido = v => v != null && !isNaN(v);

    // Sinais de alerta marcados pelo profissional.
    (dados.sinais || []).forEach(chave => {
      if (SINAIS[chave]) subir(SINAIS[chave][0], SINAIS[chave][1]);
    });

    // Temperatura
    if (preenchido(dados.temp)) {
      const t = dados.temp;

      if (meses < 3 && t >= 38) {
        subir(meses < 1 ? "vermelho" : "laranja", "Febre ≥ 38 °C em menor de 3 meses");
      } else if (t >= 40) {
        subir("laranja", "Febre ≥ 40 °C");
      } else if (t >= 39) {
        subir("amarelo", "Febre ≥ 39 °C");
      } else if (t >= 37.8) {
        subir("verde", "Febre");
      }

      if (meses < 3 && t < 35.5) {
        subir("laranja", "Hipotermia em menor de 3 meses");
      }
    }

    // Saturação de oxigênio
    if (preenchido(dados.spo2)) {
      if (dados.spo2 < 90) subir("vermelho", "SpO₂ < 90%");
      else if (dados.spo2 < 92) subir("laranja", "SpO₂ < 92%");
      else if (dados.spo2 < 95) subir("amarelo", "SpO₂ < 95%");
    }

    // Frequência cardíaca (acima de 25% do limite = laranja)
    if (preenchido(dados.fc) && dados.fc > fcMax) {
      const cor = dados.fc > fcMax * 1.25 ? "laranja" : "amarelo";
      subir(cor, "FC " + dados.fc + " acima do esperado para a idade (máx. ~" + fcMax + ")");
    }

    // Frequência respiratória
    if (preenchido(dados.fr) && dados.fr > frMax) {
      const cor = dados.fr > frMax * 1.25 ? "laranja" : "amarelo";
      subir(cor, "FR " + dados.fr + " acima do esperado para a idade (máx. ~" + frMax + ")");
    }

    return { risco: ORD[nivel], motivos, alvoMin: ALVO[ORD[nivel]] };
  }

  /* =====================================================
     FORMULÁRIO DE MEDICAMENTOS
       modo "dose" = mg/kg por dose
       modo "dia"  = mg/kg/dia, dividido em "vezes"
       conc        = concentração em mg/mL
     ===================================================== */
  const FORM = [
    { id: "paracetamol", nome: "Paracetamol", modo: "dose", min: 10, max: 15, pad: 10, vezes: 4, intervalo: "6/6 h", conc: 200, apres: "gotas 200 mg/mL", maxDiaKg: 75 },
    { id: "dipirona", nome: "Dipirona", modo: "dose", min: 10, max: 25, pad: 15, vezes: 4, intervalo: "6/6 h", conc: 500, apres: "gotas 500 mg/mL", minMeses: 3, minKg: 5 },
    { id: "ibuprofeno", nome: "Ibuprofeno", modo: "dose", min: 5, max: 10, pad: 10, vezes: 3, intervalo: "8/8 h", conc: 50, apres: "gotas 50 mg/mL", minMeses: 6, maxDiaKg: 40, nota: "Evitar se houver suspeita de dengue." },
    { id: "amoxicilina", nome: "Amoxicilina", modo: "dia", min: 25, max: 50, pad: 50, vezes: 3, intervalo: "8/8 h", conc: 50, apres: "suspensão 250 mg/5 mL" },
    { id: "azitromicina", nome: "Azitromicina", modo: "dose", min: 10, max: 10, pad: 10, vezes: 1, intervalo: "1x ao dia", conc: 40, apres: "suspensão 200 mg/5 mL", maxDose: 500 },
    { id: "ondansetrona", nome: "Ondansetrona", modo: "dose", min: 0.1, max: 0.15, pad: 0.15, vezes: 3, intervalo: "8/8 h", conc: 0.8, apres: "solução 4 mg/5 mL", maxDose: 8, minMeses: 6 },
    { id: "prednisolona", nome: "Prednisolona", modo: "dia", min: 1, max: 2, pad: 1, vezes: 1, intervalo: "1x ao dia", conc: 3, apres: "solução 3 mg/mL", maxDose: 40 }
  ];

  /* =====================================================
     CÁLCULO DE DOSE
     f = item do FORM · kg = peso · meses = idade · mgkg = dose escolhida
     Devolve { mg, ml, vezes, intervalo, alertas } ou { erro }.
     ===================================================== */
  function dose(f, kg, meses, mgkg) {
    if (!(kg > 0)) return { erro: "Informe o peso." };

    const alertas = [];
    mgkg = mgkg > 0 ? mgkg : f.pad;

    if (f.minMeses && meses < f.minMeses) {
      alertas.push("Não recomendado abaixo de " + f.minMeses + " meses.");
    }
    if (f.minKg && kg < f.minKg) {
      alertas.push("Não recomendado abaixo de " + f.minKg + " kg.");
    }
    if (mgkg < f.min || mgkg > f.max) {
      alertas.push(
        "Dose fora da faixa usual (" + f.min + "–" + f.max + " mg/kg" +
        (f.modo === "dia" ? "/dia" : "/dose") + ")."
      );
    }

    // mg por dose: no modo "dia" divide pelo número de vezes.
    let mg = f.modo === "dia" ? (mgkg * kg) / f.vezes : mgkg * kg;

    if (f.maxDose && mg > f.maxDose) {
      mg = f.maxDose;
      alertas.push("Limitado à dose máxima de " + f.maxDose + " mg.");
    }
    if (f.maxDiaKg && (mg * f.vezes) / kg > f.maxDiaKg) {
      alertas.push("Ultrapassa " + f.maxDiaKg + " mg/kg/dia.");
    }

    return {
      mg: +mg.toFixed(1),
      ml: +(mg / f.conc).toFixed(1),
      vezes: f.vezes,
      intervalo: f.intervalo,
      alertas
    };
  }

  /* =====================================================
     MANUTENÇÃO HÍDRICA (Holliday-Segar)
     Devolve mL por dia e mL por hora.
     ===================================================== */
  function manutencao(kg) {
    let porDia;
    if (kg <= 10) porDia = kg * 100;
    else if (kg <= 20) porDia = 1000 + (kg - 10) * 50;
    else porDia = 1500 + (kg - 20) * 20;

    return { dia: Math.round(porDia), hora: +(porDia / 24).toFixed(1) };
  }

  return { ORD, ALVO, SINAIS, FORM, idade, classificar, dose, manutencao };
});
