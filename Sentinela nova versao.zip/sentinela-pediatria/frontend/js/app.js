/* =====================================================
   app.js — funções comuns a todas as telas

   Índice:
     1. Atalhos e ajudantes
     2. Comunicação com o servidor (api)
     3. Módulos do sistema e permissões por setor
     4. Barra lateral expansível (guard)
     5. Avisos rápidos (toast)
     6. Componentes reutilizáveis
     7. Ajudantes de tela (abas, crianças, alertas da IA)
   ===================================================== */

/* =====================================================
   1. ATALHOS E AJUDANTES
   ===================================================== */

// $("#id") encontra um elemento; $$(".classe") encontra vários.
const $ = (seletor, raiz = document) => raiz.querySelector(seletor);
const $$ = (seletor, raiz = document) => [...raiz.querySelectorAll(seletor)];

// Protege contra HTML malicioso ao mostrar texto digitado por alguém.
function esc(valor) {
  return String(valor ?? "").replace(/[&<>"']/g, caractere => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  }[caractere]));
}

// Data de hoje no horário do aparelho, no formato AAAA-MM-DD.
function hojeLocal() {
  const agora = new Date();
  agora.setMinutes(agora.getMinutes() - agora.getTimezoneOffset());
  return agora.toISOString().slice(0, 10);
}

// Início do dia de hoje (usado para contar "hoje" no painel).
function inicioDoDiaISO() {
  const agora = new Date();
  agora.setHours(0, 0, 0, 0);
  return agora.toISOString();
}

// "2026-11-14T10:30:00Z" -> "14/11/2026 10:30:00"
const dataHora = iso => (iso ? new Date(iso).toLocaleString("pt-BR") : "—");

// Usuário que está logado nesta aba (ou null).
function usuarioAtual() {
  return JSON.parse(sessionStorage.getItem("u") || "null");
}

/* =====================================================
   2. COMUNICAÇÃO COM O SERVIDOR
   api("/rota")                   -> GET
   api("/rota", { dados })        -> POST
   api("/rota", { dados }, "PUT") -> outro método
   ===================================================== */
async function api(url, corpo, metodo) {
  const sessao = usuarioAtual();
  const opcoes = {
    method: metodo || (corpo ? "POST" : "GET"),
    headers: { "Content-Type": "application/json" }
  };
  if (sessao && sessao.token) opcoes.headers.Authorization = "Bearer " + sessao.token;
  if (corpo) opcoes.body = JSON.stringify(corpo);

  let resposta;
  try {
    resposta = await fetch(url, opcoes);
  } catch {
    throw new Error("Sem conexão com o servidor.");
  }

  const dados = await resposta.json().catch(() => ({}));

  // Sessão vencida: volta ao login (exceto na própria tela de login).
  const ehLogin = url === "/login" || url === "/admin/acesso";
  if (resposta.status === 401 && !ehLogin) {
    sessionStorage.removeItem("u");
    location.href = "index.html";
    throw new Error(dados.erro || "Sessão expirada.");
  }

  if (!resposta.ok) {
    const erro = new Error(dados.erro || "Erro " + resposta.status);
    erro.status = resposta.status;
    erro.dados = dados; // ex.: lista de alertas da IA
    throw erro;
  }
  return dados;
}

/* =====================================================
   3. MÓDULOS DO SISTEMA E PERMISSÕES POR SETOR

   Para criar uma tela nova no menu:
     1. adicione uma linha em MODULOS (escolha o grupo);
     2. liste a chave nos setores que podem vê-la em ACESSO.
   ===================================================== */

// Categorias do menu lateral, na ordem em que aparecem.
const GRUPOS = [
  { nome: "Geral",                  icone: "🏠" },
  { nome: "Atendimento",            icone: "🩺" },
  { nome: "Saúde mental",           icone: "💬" },
  { nome: "Infantil",               icone: "🧸" },
  { nome: "Enfermagem",             icone: "🩹" },
  { nome: "Administração",          icone: "🏢" },
  { nome: "Operacional",            icone: "📦" },
  { nome: "Comunicação",            icone: "📣" },
  { nome: "Sentinela Intelligence", icone: "🛡️" }
];

const MODULOS = {
  inicio:          { arquivo: "inicio.html",          rotulo: "Painel inicial",         icone: "🏠", grupo: "Geral",   desc: "Resumo do seu dia, avisos e atalhos" },
  admin:           { arquivo: "admin.html",           rotulo: "Indicadores",            icone: "📊", grupo: "Geral",   desc: "Números do atendimento e do cuidado emocional" },

  atendimento:     { arquivo: "atendimento.html",     rotulo: "Recepção",               icone: "🧾", grupo: "Atendimento", desc: "Cadastro da criança e do responsável" },
  triagem:         { arquivo: "triagem.html",         rotulo: "Triagem",                icone: "🩺", grupo: "Atendimento", desc: "Sinais vitais e classificação de risco" },
  medico:          { arquivo: "medico.html",          rotulo: "Pediatra",               icone: "👩‍⚕️", grupo: "Atendimento", desc: "Fila por gravidade, consulta e prescrição" },
  medicacoes:      { arquivo: "medicacoes.html",      rotulo: "Prescrições",            icone: "📋", grupo: "Atendimento", desc: "Histórico de prescrições" },

  psicologia:      { arquivo: "psicologia.html",      rotulo: "Psicologia",             icone: "💬", grupo: "Saúde mental", desc: "Sessões e pedidos de atendimento" },
  psiquiatria:     { arquivo: "psiquiatria.html",     rotulo: "Psiquiatria infantil",   icone: "🧠", grupo: "Saúde mental", desc: "Avaliações de psiquiatria infantil" },
  acompanhamento:  { arquivo: "acompanhamento.html",  rotulo: "Acompanhamento emocional", icone: "💗", grupo: "Saúde mental", desc: "Humor, sessões e evolução de cada criança" },
  familia:         { arquivo: "familia.html",         rotulo: "Apoio aos familiares",   icone: "👨‍👩‍👧", grupo: "Saúde mental", desc: "Apoio psicológico a pais e responsáveis" },
  encaminhamentos: { arquivo: "encaminhamentos.html", rotulo: "Encaminhamentos",        icone: "🔀", grupo: "Saúde mental", desc: "Pedidos entre profissionais" },

  acolhimento:     { arquivo: "acolhimento.html",     rotulo: "Espaços de acolhimento", icone: "🧸", grupo: "Infantil", desc: "Brinquedoteca, recreação e convivência" },
  sensorial:       { arquivo: "sensorial.html",       rotulo: "Espaço sensorial",       icone: "✨", grupo: "Infantil", desc: "Sessões de calma e estímulos sensoriais" },
  bemestar:        { arquivo: "bemestar.html",        rotulo: "Atividades e agenda",    icone: "🎨", grupo: "Infantil", desc: "Catálogo de atividades e agenda da criança" },
  programacao:     { arquivo: "programacao.html",     rotulo: "Programação infantil",   icone: "🗓️", grupo: "Infantil", desc: "Atividades em grupo, salas e vagas" },
  pedagogia:       { arquivo: "pedagogia.html",       rotulo: "Pedagogia hospitalar",   icone: "✏️", grupo: "Infantil", desc: "Classe hospitalar e atividades escolares" },
  desenvolvimento: { arquivo: "desenvolvimento.html", rotulo: "Desenvolvimento",        icone: "🌱", grupo: "Infantil", desc: "Marcos e evolução por área" },
  criancas:        { arquivo: "criancas.html",        rotulo: "Cantinho da criança",    icone: "🌈", grupo: "Infantil", desc: "Humor, dor, respiração e jogos" },

  enfermagem:      { arquivo: "enfermagem.html",      rotulo: "Cuidados de enfermagem", icone: "🩹", grupo: "Enfermagem", desc: "Medicação, sinais vitais e cuidados" },

  usuarios:        { arquivo: "usuarios.html",        rotulo: "Usuários",               icone: "👥", grupo: "Administração", desc: "Cadastrar, editar e excluir contas" },
  profissionais:   { arquivo: "profissionais.html",   rotulo: "Profissionais",          icone: "🧑‍⚕️", grupo: "Administração", desc: "Equipe, registros e turnos" },
  setores:         { arquivo: "setores.html",         rotulo: "Setores",                icone: "🏢", grupo: "Administração", desc: "Controle de setores do hospital" },
  salas:           { arquivo: "salas.html",           rotulo: "Salas",                  icone: "🚪", grupo: "Administração", desc: "Salas, ocupação e reservas" },
  controle:        { arquivo: "controle.html",        rotulo: "Atividades e atendimentos", icone: "📑", grupo: "Administração", desc: "Tudo o que aconteceu, com filtros" },
  relatorios:      { arquivo: "relatorios.html",      rotulo: "Relatórios",             icone: "📈", grupo: "Administração", desc: "Números por período, setor e profissional" },

  almoxarifado:    { arquivo: "almoxarifado.html",    rotulo: "Farmácia e almoxarifado", icone: "📦", grupo: "Operacional", desc: "Estoque de medicamentos" },
  altas:           { arquivo: "altas.html",           rotulo: "Altas",                  icone: "🏥", grupo: "Operacional", desc: "Alta e registro de saída" },

  avisos:          { arquivo: "avisos.html",          rotulo: "Avisos e mural",         icone: "📣", grupo: "Comunicação", desc: "Mural da equipe e avisos da TV" },
  tv:              { arquivo: "tv.html",              rotulo: "Painel de chamadas",     icone: "📺", grupo: "Comunicação", desc: "Chamada de pacientes (abre em nova aba)", externo: true },

  ia:              { arquivo: "ia.html",              rotulo: "Sentinela Intelligence", icone: "🛡️", grupo: "Sentinela Intelligence", desc: "Alertas, conferências e auditoria" }
};

// Nome de cada setor (perfil de usuário) em português.
const SETORES = {
  atendimento:  "Atendimento (recepção)",
  triagem:      "Triagem",
  medico:       "Pediatra",
  enfermagem:   "Enfermagem",
  psicologia:   "Psicologia",
  psiquiatria:  "Psiquiatria infantil",
  pedagogia:    "Pedagogia hospitalar",
  bemestar:     "Equipe de bem-estar",
  almoxarifado: "Farmácia / Almoxarifado",
  admin:        "Administrador"
};

// Telas que todo mundo que entrou no sistema pode abrir.
const PARA_TODOS = ["inicio", "avisos"];

// Quais telas cada setor pode abrir.
const ACESSO = {
  atendimento:  [...PARA_TODOS, "atendimento", "tv", "ia"],
  triagem:      [...PARA_TODOS, "triagem", "ia"],
  medico:       [...PARA_TODOS, "medico", "medicacoes", "altas", "encaminhamentos", "acompanhamento", "bemestar", "criancas", "ia"],
  enfermagem:   [...PARA_TODOS, "enfermagem", "medicacoes", "encaminhamentos", "acompanhamento", "bemestar", "criancas", "ia"],
  psicologia:   [...PARA_TODOS, "psicologia", "acompanhamento", "familia", "encaminhamentos", "sensorial", "desenvolvimento", "bemestar", "criancas"],
  psiquiatria:  [...PARA_TODOS, "psiquiatria", "psicologia", "acompanhamento", "familia", "encaminhamentos", "desenvolvimento", "bemestar", "criancas"],
  pedagogia:    [...PARA_TODOS, "pedagogia", "desenvolvimento", "programacao", "acolhimento", "encaminhamentos", "bemestar", "criancas"],
  bemestar:     [...PARA_TODOS, "acolhimento", "sensorial", "bemestar", "programacao", "encaminhamentos", "desenvolvimento", "criancas"],
  almoxarifado: [...PARA_TODOS, "almoxarifado", "medicacoes", "ia"],
  // O administrador gerencia o hospital, mas não lê prontuário de saúde mental
  // (psicologia, psiquiatria, apoio a familiares e acompanhamento emocional).
  admin:        Object.keys(MODULOS).filter(chave => !["psicologia", "psiquiatria", "familia", "acompanhamento"].includes(chave))
};

// Todos entram pelo Painel inicial (de lá vão para onde precisam).
const HOME = Object.fromEntries(Object.keys(ACESSO).map(setor => [setor, "inicio.html"]));

/* =====================================================
   4. BARRA LATERAL EXPANSÍVEL
   Cada tela chama guard("nome-da-tela") no começo do script.
   Se a pessoa não estiver logada (ou não tiver permissão),
   volta para o login. Senão, monta o menu e o topo.

   O menu agrupa as telas em categorias que abrem e fecham,
   tem busca, modo compacto (só ícones) e selinhos com o
   número de pendências. As escolhas ficam salvas no aparelho.
   ===================================================== */
function guard(pagina) {
  const usuario = usuarioAtual();
  const permitidas = usuario && usuario.token ? ACESSO[usuario.tipo] || [] : [];

  if (!usuario || !permitidas.includes(pagina)) {
    location.href = "index.html";
    return;
  }

  montarLayout(pagina, usuario, permitidas);
}

/* ---------- Preferências do menu (ficam no aparelho) ---------- */
const CHAVE_MENU = "sentinela.menu";

function lerPreferenciasMenu() {
  try {
    return JSON.parse(localStorage.getItem(CHAVE_MENU)) || {};
  } catch {
    return {};
  }
}

function salvarPreferenciasMenu(preferencias) {
  try {
    localStorage.setItem(CHAVE_MENU, JSON.stringify(preferencias));
  } catch { /* navegador sem armazenamento: o menu só não lembra */ }
}

// "Saúde mental" -> "saude-mental" (usado em ids)
const slug = texto => texto.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[^a-z0-9]+/g, "-");

// Texto sem acento e em minúsculas, para a busca.
const semAcento = texto => String(texto).normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();

/* ---------- HTML do menu ---------- */
function htmlLinkMenu(chave, pagina) {
  const modulo = MODULOS[chave];
  const atual = chave === pagina;
  const novaAba = modulo.externo ? ' target="_blank" rel="noopener"' : "";

  return `
    <a class="menu-link${atual ? " on" : ""}" href="${modulo.arquivo}" data-chave="${chave}"
       data-busca="${esc(semAcento(modulo.rotulo + " " + modulo.desc))}" title="${esc(modulo.rotulo)}"${novaAba}${atual ? ' aria-current="page"' : ""}>
      <span class="menu-icone" aria-hidden="true">${modulo.icone}</span>
      <span class="menu-texto">${esc(modulo.rotulo)}${modulo.externo ? " ↗" : ""}</span>
      <span class="menu-badge" data-badge="${chave}" hidden></span>
    </a>`;
}

function htmlGrupoMenu(grupo, pagina, permitidas, abertos) {
  const chaves = permitidas.filter(chave => MODULOS[chave].grupo === grupo.nome);
  if (!chaves.length) return "";

  const id = "sub-" + slug(grupo.nome);
  const aberto = abertos.includes(grupo.nome);

  return `
    <section class="menu-grupo${aberto ? " aberto" : ""}" data-grupo="${esc(grupo.nome)}">
      <button type="button" class="menu-grupo-btn" aria-expanded="${aberto}" aria-controls="${id}" title="${esc(grupo.nome)}">
        <span class="menu-icone" aria-hidden="true">${grupo.icone}</span>
        <span class="menu-texto menu-grupo-nome">${esc(grupo.nome)}</span>
        <span class="menu-badge menu-badge-grupo" hidden></span>
        <span class="menu-seta" aria-hidden="true">›</span>
      </button>
      <div class="menu-sub" id="${id}">
        ${chaves.map(chave => htmlLinkMenu(chave, pagina)).join("")}
      </div>
    </section>`;
}

function montarLayout(pagina, usuario, permitidas) {
  const conteudo = document.querySelector(".container");
  const modulo = MODULOS[pagina];
  const preferencias = lerPreferenciasMenu();

  document.title = modulo.rotulo + " - Sentinela Pediatria";

  // Grupos abertos: os que a pessoa deixou abertos + o da tela atual.
  const abertos = new Set(preferencias.abertos || ["Geral"]);
  abertos.add(modulo.grupo);

  const menuGrupos = GRUPOS
    .map(grupo => htmlGrupoMenu(grupo, pagina, permitidas, [...abertos]))
    .join("");

  const dataExtenso = new Date().toLocaleDateString("pt-BR", { weekday: "long", day: "numeric", month: "long" });
  const hoje = dataExtenso.charAt(0).toUpperCase() + dataExtenso.slice(1);

  const estrutura = document.createElement("div");
  estrutura.className = "shell";
  estrutura.innerHTML = `
    <aside class="menu" id="menu" aria-label="Menu principal">
      <div class="menu-topo">
        <a class="menu-marca" href="${HOME[usuario.tipo]}">
          <span class="menu-marca-icone" aria-hidden="true">🧸</span>
          <span class="menu-texto">Sentinela<br>Pediatria</span>
        </a>
        <button type="button" class="menu-compactar" id="btnCompactar" aria-label="Recolher menu" title="Recolher ou expandir o menu">‹</button>
      </div>

      <div class="menu-busca">
        <input type="search" id="menuBusca" placeholder="Buscar tela…  ( / )" aria-label="Buscar tela no menu" autocomplete="off">
      </div>

      <nav id="menuNav" aria-label="Telas do sistema">${menuGrupos}</nav>
      <p class="menu-vazio" id="menuVazio" hidden>Nenhuma tela encontrada.</p>

      <div class="menu-rodape">
        <div class="menu-usuario">
          <span class="avatar" aria-hidden="true">${esc(usuario.usuario.charAt(0).toUpperCase())}</span>
          <span class="menu-texto">
            <b>${esc(usuario.usuario)}</b>
            <small>${esc(SETORES[usuario.tipo] || usuario.tipo)}</small>
          </span>
        </div>
        <a href="#" id="sair" class="menu-link" title="Sair">
          <span class="menu-icone" aria-hidden="true">🚪</span><span class="menu-texto">Sair</span>
        </a>
      </div>
    </aside>

    <div class="menu-fundo" id="menuFundo"></div>

    <div class="principal">
      <header class="topo">
        <button type="button" class="btn-menu" id="btnMenu"
                aria-label="Abrir menu" aria-controls="menu" aria-expanded="false">☰</button>
        <div class="topo-titulo">
          <small>${esc(modulo.grupo)}</small>
          <b>${modulo.icone} ${esc(modulo.rotulo)}</b>
        </div>
        <span class="topo-data">${esc(hoje)}</span>
      </header>
    </div>`;

  document.body.prepend(estrutura);
  estrutura.querySelector(".principal").append(conteudo);

  document.body.classList.toggle("menu-compacto", !!preferencias.compacto);

  ligarEventosDoMenu(modulo);
  carregarContadoresDoMenu();
  setInterval(carregarContadoresDoMenu, 60000);
}

/* ---------- Comportamento do menu ---------- */
function ligarEventosDoMenu(modulo) {
  const botao = $("#btnMenu");
  const menu = $("#menu");

  // Gaveta no celular.
  const abrirGaveta = abrir => {
    document.body.classList.toggle("menu-aberto", abrir);
    botao.setAttribute("aria-expanded", String(abrir));
  };
  botao.onclick = () => abrirGaveta(!document.body.classList.contains("menu-aberto"));
  $("#menuFundo").onclick = () => abrirGaveta(false);

  // Grava o estado atual (grupos abertos e modo compacto).
  const salvar = () => salvarPreferenciasMenu({
    abertos: $$(".menu-grupo.aberto").map(grupo => grupo.dataset.grupo),
    compacto: document.body.classList.contains("menu-compacto")
  });

  const alternarGrupo = (grupo, abrir) => {
    grupo.classList.toggle("aberto", abrir);
    grupo.querySelector(".menu-grupo-btn").setAttribute("aria-expanded", String(abrir));
  };

  // Clique no título de uma categoria: abre ou fecha.
  menu.addEventListener("click", evento => {
    const titulo = evento.target.closest(".menu-grupo-btn");
    if (!titulo) return;

    const grupo = titulo.parentElement;

    // No modo compacto, clicar numa categoria expande o menu já nela.
    if (document.body.classList.contains("menu-compacto")) {
      document.body.classList.remove("menu-compacto");
      alternarGrupo(grupo, true);
    } else {
      alternarGrupo(grupo, !grupo.classList.contains("aberto"));
    }
    atualizarBadgesDosGrupos();
    salvar();
  });

  // Botão "‹ ›": recolhe para só ícones.
  $("#btnCompactar").onclick = () => {
    document.body.classList.toggle("menu-compacto");
    salvar();
  };

  // Busca: mostra só as telas que combinam, com as categorias abertas.
  const nav = $("#menuNav");
  $("#menuBusca").oninput = evento => {
    const termo = semAcento(evento.target.value.trim());
    nav.classList.toggle("filtrando", !!termo);

    let achou = 0;
    $$(".menu-link[data-chave]").forEach(link => {
      const combina = !termo || link.dataset.busca.includes(termo);
      link.hidden = !combina;
      if (combina) achou++;
    });
    $$(".menu-grupo").forEach(grupo => {
      grupo.hidden = !!termo && !grupo.querySelector(".menu-link:not([hidden])");
    });
    $("#menuVazio").hidden = achou > 0;
  };

  // Teclado: "/" foca a busca; Esc limpa a busca ou fecha a gaveta.
  addEventListener("keydown", evento => {
    const digitando = /^(INPUT|TEXTAREA|SELECT)$/.test(document.activeElement.tagName);

    if (evento.key === "/" && !digitando && !evento.ctrlKey && !evento.metaKey) {
      evento.preventDefault();
      document.body.classList.remove("menu-compacto");
      abrirGaveta(true);
      $("#menuBusca").focus();
    } else if (evento.key === "Escape") {
      const busca = $("#menuBusca");
      if (busca.value) {
        busca.value = "";
        busca.dispatchEvent(new Event("input"));
      }
      abrirGaveta(false);
    }
  });

  // Enter na busca abre a primeira tela encontrada.
  $("#menuBusca").onkeydown = evento => {
    if (evento.key !== "Enter") return;
    const primeiro = $(".menu-link[data-chave]:not([hidden])");
    if (primeiro) primeiro.click();
  };

  $("#sair").onclick = evento => {
    evento.preventDefault();
    sessionStorage.removeItem("u");
    location.href = "index.html";
  };

  // A tela atual fica visível mesmo com o menu rolado.
  const atual = $(".menu-link.on");
  if (atual) atual.scrollIntoView({ block: "nearest" });
}

/* ---------- Selinhos de pendências ---------- */
// Soma os selinhos das telas de cada categoria (mostrada quando ela está fechada).
function atualizarBadgesDosGrupos() {
  $$(".menu-grupo").forEach(grupo => {
    const soma = $$(".menu-badge[data-badge]", grupo)
      .reduce((total, selo) => total + (selo.hidden ? 0 : Number(selo.textContent) || 0), 0);

    const selo = grupo.querySelector(".menu-badge-grupo");
    selo.textContent = soma > 99 ? "99+" : soma;
    selo.hidden = soma === 0;
  });
}

async function carregarContadoresDoMenu() {
  let contadores;
  try {
    contadores = await api("/menu/contadores");
  } catch {
    return; // sem rede: o menu continua funcionando sem os selinhos
  }

  $$(".menu-badge[data-badge]").forEach(selo => {
    const valor = contadores[selo.dataset.badge] || 0;
    selo.textContent = valor > 99 ? "99+" : valor;
    selo.hidden = valor === 0;
    selo.classList.toggle("urgente", selo.dataset.badge === "ia");
  });
  atualizarBadgesDosGrupos();
}

/* =====================================================
   5. AVISOS RÁPIDOS
   toast("Salvo!")          -> aviso normal
   toast("Deu erro", true)  -> aviso vermelho
   ===================================================== */
function toast(mensagem, erro) {
  const aviso = document.createElement("div");
  aviso.className = "toast" + (erro ? " err" : "");
  aviso.textContent = mensagem;
  aviso.setAttribute("role", "status");
  document.body.append(aviso);

  setTimeout(() => aviso.remove(), 3500);
}

/* =====================================================
   6. COMPONENTES REUTILIZÁVEIS
   ===================================================== */

// Cria as carinhas de humor dentro de um elemento.
// Devolve { valor(), limpar() }. Clicar de novo na mesma carinha desmarca.
//   const humor = seletorHumor($("#meuHumor"), valor => console.log(valor));
function seletorHumor(container, aoEscolher) {
  let escolhido = null;

  container.classList.add("humor-opcoes");
  container.innerHTML = Bemestar.HUMORES.map(h => `
    <button type="button" class="humor-btn" data-valor="${h.valor}" aria-pressed="false">
      <span class="humor-emoji" aria-hidden="true">${h.emoji}</span>
      <small>${esc(h.rotulo)}</small>
    </button>`).join("");

  const atualizarBotoes = () => {
    container.querySelectorAll(".humor-btn").forEach(botao => {
      const marcado = Number(botao.dataset.valor) === escolhido;
      botao.setAttribute("aria-pressed", String(marcado));
    });
  };

  container.onclick = evento => {
    const botao = evento.target.closest(".humor-btn");
    if (!botao) return;

    const valor = Number(botao.dataset.valor);
    escolhido = escolhido === valor ? null : valor;
    atualizarBotoes();

    if (aoEscolher) aoEscolher(escolhido);
  };

  return {
    valor: () => escolhido,
    limpar() {
      escolhido = null;
      atualizarBotoes();
    }
  };
}

// Monta as <option> de um <select> com as crianças.
function opcoesPacientes(lista, textoInicial) {
  const inicial = `<option value="">${esc(textoInicial)}</option>`;
  const opcoes = lista.map(p =>
    `<option value="${p.id}">${esc(p.nome)} · ${esc(p.idadeTexto)}</option>`
  );
  return inicial + opcoes.join("");
}

// Emoji + texto do humor (ex.: "😄 Muito feliz"), ou "—" se vazio.
function rotuloHumor(valor) {
  const humor = Bemestar.humorPorValor(valor);
  return humor ? humor.emoji + " " + humor.rotulo : "—";
}

// Nome amigável da urgência de um encaminhamento.
function rotuloUrgencia(id) {
  const urgencia = Bemestar.URGENCIAS.find(u => u.id === id);
  return urgencia ? urgencia.nome : id;
}

/* =====================================================
   7. AJUDANTES DE TELA
   ===================================================== */

// "2026-11-19T14:30:00Z" -> "19/11 14:30"
const dataCurta = iso => (iso
  ? new Date(iso).toLocaleString("pt-BR", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" })
  : "—");

// Texto "só a data" (AAAA-MM-DD) -> "19/11/2026"
const dataBR = texto => (texto ? texto.split("-").reverse().join("/") : "—");

// Preenche um <select> com as crianças em atendimento. Devolve a lista.
async function carregarCriancas(select, textoInicial = "Selecione a criança...") {
  const criancas = await api("/pacientes?ativos=1");
  select.innerHTML = opcoesPacientes(criancas, textoInicial);
  return criancas;
}

// Lembra nome e registro do profissional neste aparelho (para não digitar toda vez).
function lembrarProfissional(campoNome, campoRegistro) {
  const chave = "sentinela.profissional";
  let guardado = {};
  try { guardado = JSON.parse(localStorage.getItem(chave)) || {}; } catch { /* sem armazenamento */ }

  if (campoNome && !campoNome.value) campoNome.value = guardado.nome || "";
  if (campoRegistro && !campoRegistro.value) campoRegistro.value = guardado.registro || "";

  const guardar = () => {
    try {
      localStorage.setItem(chave, JSON.stringify({
        nome: campoNome ? campoNome.value : "",
        registro: campoRegistro ? campoRegistro.value : ""
      }));
    } catch { /* ignora */ }
  };
  [campoNome, campoRegistro].filter(Boolean).forEach(campo => campo.addEventListener("change", guardar));
}

// Abas: <div class="abas" role="tablist"><button data-aba="x">…</button></div>
// e painéis <section data-painel="x">. Devolve mostrar(nome).
function ligarAbas(raiz, aoMostrar) {
  const botoes = $$(".abas [data-aba]", raiz);
  const paineis = $$("[data-painel]", raiz);

  const mostrar = nome => {
    botoes.forEach(botao => {
      const ativo = botao.dataset.aba === nome;
      botao.setAttribute("aria-selected", String(ativo));
      botao.tabIndex = ativo ? 0 : -1;
    });
    paineis.forEach(painel => { painel.hidden = painel.dataset.painel !== nome; });
    if (aoMostrar) aoMostrar(nome);
  };

  botoes.forEach(botao => {
    botao.setAttribute("role", "tab");
    botao.onclick = () => mostrar(botao.dataset.aba);
  });

  // Setas do teclado trocam de aba (só as que estão visíveis).
  $(".abas", raiz).addEventListener("keydown", evento => {
    if (!["ArrowRight", "ArrowLeft"].includes(evento.key)) return;
    const visiveis = botoes.filter(b => !b.hidden);
    const atual = visiveis.findIndex(b => b.getAttribute("aria-selected") === "true");
    const proximo = (atual + (evento.key === "ArrowRight" ? 1 : -1) + visiveis.length) % visiveis.length;
    visiveis[proximo].focus();
    mostrar(visiveis[proximo].dataset.aba);
  });

  mostrar((botoes.find(b => !b.hidden) || botoes[0]).dataset.aba);
  return mostrar;
}

// Nome amigável do destino de um encaminhamento.
const nomeDestino = id => (Bemestar.NOMES_DESTINO || {})[id] || id;

/* ---------- Alertas da Sentinela Intelligence ---------- */
const ROTULO_GRAVIDADE = { alta: "Grave", media: "Atenção", baixa: "Informativo" };

function htmlAlertasIA(alertas) {
  return alertas.map(a => `
    <div class="ia-alerta ${esc(a.gravidade)}" role="${a.gravidade === "alta" ? "alert" : "note"}">
      <span class="ia-selo">${ROTULO_GRAVIDADE[a.gravidade] || a.gravidade}</span>
      <div>
        <b>${esc(a.titulo)}</b>
        <p>${esc(a.detalhe)}</p>
        ${a.paciente ? `<small>${esc(a.paciente)}${a.origem ? " · " + esc(a.origem) : ""}</small>` : ""}
        ${a.ciente ? `<small class="ok">✔ Profissional ciente${a.justificativa ? ": " + esc(a.justificativa) : ""}</small>` : ""}
      </div>
    </div>`).join("");
}

// Janela que mostra os alertas graves e pede a justificativa para continuar.
// Devolve a justificativa (texto) se a pessoa insistir, ou null se voltar para revisar.
function pedirCienciaIA(alertas, textoConfirmar = "Registrar mesmo assim") {
  return new Promise(resolver => {
    const janela = document.createElement("dialog");
    janela.className = "janela-ia";
    janela.innerHTML = `
      <h2>🛡️ Sentinela Intelligence</h2>
      <p>Encontrei ${alertas.filter(a => a.gravidade === "alta").length} alerta(s) grave(s). A decisão é sua: revise ou justifique para continuar.</p>
      <div class="ia-lista">${htmlAlertasIA(alertas)}</div>
      <label>Justificativa (obrigatória para continuar)
        <textarea id="iaJustificativa" maxlength="400" placeholder="Ex.: dose conferida com a farmácia; alergia descartada pelo responsável..."></textarea>
      </label>
      <p class="erro" id="iaErro" role="alert"></p>
      <div class="acoes" style="margin-top:12px">
        <button type="button" class="sec" id="iaVoltar">Voltar e revisar</button>
        <button type="button" class="perigo" id="iaContinuar">${esc(textoConfirmar)}</button>
      </div>`;
    document.body.append(janela);

    const fechar = valor => { janela.close(); janela.remove(); resolver(valor); };

    janela.querySelector("#iaVoltar").onclick = () => fechar(null);
    janela.addEventListener("cancel", () => fechar(null));
    janela.querySelector("#iaContinuar").onclick = () => {
      const texto = janela.querySelector("#iaJustificativa").value.trim();
      if (texto.length < 5) {
        janela.querySelector("#iaErro").textContent = "Escreva a justificativa (ao menos 5 letras).";
        return;
      }
      fechar(texto);
    };
    janela.showModal();
  });
}

// Mini gráfico de barras em HTML/CSS (sem biblioteca).
//   graficoBarras([{ rotulo: "Seg", valor: 3 }, ...])
function graficoBarras(itens, { cor = "var(--p)", unidade = "" } = {}) {
  if (!itens.length) return '<p class="vazio">Sem dados no período.</p>';
  const maximo = Math.max(...itens.map(i => i.valor), 1);

  return `<div class="barras" role="list">` + itens.map(i => `
    <div class="barra-linha" role="listitem">
      <span class="barra-rotulo" title="${esc(i.rotulo)}">${esc(i.rotulo)}</span>
      <span class="barra-trilho"><span class="barra-preenchida" style="width:${Math.round((i.valor / maximo) * 100)}%;background:${cor}"></span></span>
      <b class="barra-valor">${esc(i.valor)}${esc(unidade)}</b>
    </div>`).join("") + `</div>`;
}

// Baixa uma lista de objetos como planilha CSV (abre no Excel).
function baixarCSV(nomeArquivo, colunas, linhas) {
  const celula = valor => {
    // Evita que o Excel execute texto que começa com = + - @ (injeção de fórmula).
    let texto = String(valor ?? "");
    if (/^[=+\-@]/.test(texto)) texto = "'" + texto;
    return '"' + texto.replace(/"/g, '""') + '"';
  };
  const corpo = [colunas.map(c => celula(c.titulo)).join(";"),
    ...linhas.map(linha => colunas.map(c => celula(linha[c.campo])).join(";"))].join("\r\n");

  const arquivo = new Blob(["\ufeff" + corpo], { type: "text/csv;charset=utf-8" });
  const link = document.createElement("a");
  link.href = URL.createObjectURL(arquivo);
  link.download = nomeArquivo;
  link.click();
  URL.revokeObjectURL(link.href);
}

// Atalhos agrupados por categoria (Painel inicial e Indicadores).
// Mostra só o que o setor da pessoa pode abrir.
function htmlAtalhosPorGrupo(excluir = []) {
  const permitidas = ACESSO[usuarioAtual().tipo] || [];

  return GRUPOS.map(grupo => {
    const chaves = permitidas.filter(chave => MODULOS[chave].grupo === grupo.nome && !excluir.includes(chave));
    if (!chaves.length) return "";

    return `
      <section class="categoria-bloco">
        <h3>${grupo.icone} ${esc(grupo.nome)}</h3>
        <div class="atalhos">
          ${chaves.map(chave => {
            const m = MODULOS[chave];
            return `
              <a class="atalho" href="${m.arquivo}"${m.externo ? ' target="_blank" rel="noopener"' : ""}>
                <span class="icone" aria-hidden="true">${m.icone}</span>
                <b>${esc(m.rotulo)}</b>
                <small>${esc(m.desc)}</small>
                <span class="menu-badge" data-badge="${chave}" hidden></span>
              </a>`;
          }).join("")}
        </div>
      </section>`;
  }).join("");
}
