/* =====================================================
   hospital.js — listas das novas áreas do hospital
   (espaços, profissionais, desenvolvimento, enfermagem,
   apoio à família, pedagogia, espaço sensorial).
   Usado pelo servidor (validação) e pelo navegador (telas).
   ATENÇÃO: conteúdo de apoio. Critérios clínicos e
   pedagógicos devem seguir o protocolo do hospital.
   ===================================================== */

(function (raiz, fabrica) {
  if (typeof module === "object" && module.exports) {
    module.exports = fabrica();
  } else {
    raiz.Hospital = fabrica();
  }
})(this, function () {

  /* ---------- Salas e espaços ---------- */
  const TIPOS_SALA = [
    { id: "brinquedoteca", nome: "Brinquedoteca",           icone: "🧸", acolhimento: true },
    { id: "recreacao",     nome: "Sala de recreação",       icone: "🎲", acolhimento: true },
    { id: "sensorial",     nome: "Espaço sensorial",        icone: "✨", acolhimento: true },
    { id: "convivencia",   nome: "Área de convivência",     icone: "🛋️", acolhimento: true },
    { id: "pedagogia",     nome: "Sala de pedagogia",       icone: "✏️" },
    { id: "psicologia",    nome: "Consultório de psicologia", icone: "💬" },
    { id: "psiquiatria",   nome: "Consultório de psiquiatria", icone: "🧠" },
    { id: "consultorio",   nome: "Consultório pediátrico",  icone: "🩺" },
    { id: "triagem",       nome: "Sala de triagem",         icone: "📋" },
    { id: "outra",         nome: "Outra",                   icone: "🚪" }
  ];

  const STATUS_SALA = [
    { id: "ativa",      nome: "Em funcionamento" },
    { id: "manutencao", nome: "Em manutenção" },
    { id: "fechada",    nome: "Fechada" }
  ];

  /* ---------- Setores ---------- */
  const TIPOS_SETOR = [
    { id: "assistencial",   nome: "Assistencial" },
    { id: "infantil",       nome: "Acolhimento e desenvolvimento infantil" },
    { id: "apoio",          nome: "Apoio" },
    { id: "administrativo", nome: "Administrativo" }
  ];

  /* ---------- Profissionais ---------- */
  const CATEGORIAS_PROFISSIONAL = [
    { id: "medico",         nome: "Médico(a)",                conselho: "CRM" },
    { id: "enfermeiro",     nome: "Enfermeiro(a)",            conselho: "COREN" },
    { id: "tecnico-enf",    nome: "Técnico(a) de enfermagem", conselho: "COREN" },
    { id: "psicologo",      nome: "Psicólogo(a)",             conselho: "CRP" },
    { id: "psiquiatra",     nome: "Psiquiatra",               conselho: "CRM" },
    { id: "pedagogo",       nome: "Pedagogo(a) hospitalar",   conselho: "" },
    { id: "terapeuta-ocup", nome: "Terapeuta ocupacional",    conselho: "CREFITO" },
    { id: "recreacionista", nome: "Recreacionista / brinquedista", conselho: "" },
    { id: "assist-social",  nome: "Assistente social",        conselho: "CRESS" },
    { id: "farmaceutico",   nome: "Farmacêutico(a)",          conselho: "CRF" },
    { id: "recepcao",       nome: "Recepção / administrativo", conselho: "" },
    { id: "voluntario",     nome: "Voluntário(a)",            conselho: "" },
    { id: "outro",          nome: "Outro",                    conselho: "" }
  ];

  const STATUS_PROFISSIONAL = [
    { id: "ativo",    nome: "Ativo" },
    { id: "afastado", nome: "Afastado" },
    { id: "inativo",  nome: "Inativo" }
  ];

  const TURNOS = ["Manhã", "Tarde", "Noite", "Plantão 12h", "Plantão 24h"];

  /* ---------- Espaço sensorial ---------- */
  const ESTIMULOS_SENSORIAIS = [
    { id: "luz-suave",   nome: "Luz suave / penumbra" },
    { id: "projecao",    nome: "Projeção de luzes e bolhas" },
    { id: "musica",      nome: "Música calma" },
    { id: "natureza",    nome: "Sons da natureza" },
    { id: "texturas",    nome: "Texturas e objetos táteis" },
    { id: "aroma",       nome: "Aromas suaves (sem alergia)" },
    { id: "pressao",     nome: "Pressão profunda (cobertor, almofadas)" },
    { id: "balanco",     nome: "Balanço / movimento suave" }
  ];

  const TOLERANCIA_SENSORIAL = [
    { id: "bem",       nome: "Aproveitou e relaxou" },
    { id: "neutra",    nome: "Ficou indiferente" },
    { id: "incomodo",  nome: "Mostrou incômodo (reduzir estímulos)" },
    { id: "interrompida", nome: "Sessão interrompida" }
  ];

  /* ---------- Pedagogia hospitalar ---------- */
  const TIPOS_PEDAGOGIA = [
    { id: "atividade",     nome: "Atividade escolar" },
    { id: "acompanhamento", nome: "Acompanhamento pedagógico" },
    { id: "contato-escola", nome: "Contato com a escola de origem" },
    { id: "reintegracao",  nome: "Preparo para volta à escola" }
  ];

  const DISCIPLINAS = [
    "Português / alfabetização", "Matemática", "Ciências", "História e Geografia",
    "Artes", "Inglês", "Educação infantil (lúdico)", "Projeto interdisciplinar"
  ];

  /* ---------- Acompanhamento do desenvolvimento ---------- */
  const AREAS_DESENVOLVIMENTO = [
    { id: "motor",           nome: "Motor (movimento e coordenação)" },
    { id: "linguagem",       nome: "Linguagem e comunicação" },
    { id: "cognitivo",       nome: "Cognitivo (atenção, memória, raciocínio)" },
    { id: "socioemocional",  nome: "Socioemocional (vínculos, regulação)" },
    { id: "autonomia",       nome: "Autonomia (alimentação, higiene, sono)" }
  ];

  // 1 a 4. Níveis 1 e 2 chamam a atenção da equipe.
  const ESCALA_DESENVOLVIMENTO = [
    { valor: 1, nome: "Precisa de muito apoio" },
    { valor: 2, nome: "Precisa de apoio" },
    { valor: 3, nome: "Em desenvolvimento" },
    { valor: 4, nome: "Esperado para a idade" }
  ];

  /* ---------- Apoio psicológico aos familiares ---------- */
  const TIPOS_APOIO_FAMILIAR = [
    { id: "escuta",     nome: "Escuta e acolhimento" },
    { id: "orientacao", nome: "Orientação sobre a internação / tratamento" },
    { id: "grupo",      nome: "Grupo de apoio a familiares" },
    { id: "luto",       nome: "Apoio em perda ou notícia difícil" },
    { id: "alta",       nome: "Preparo para a alta e rotina em casa" },
    { id: "rede",       nome: "Articulação com a rede de apoio (CRAS, CAPS...)" }
  ];

  const PARENTESCOS = [
    "Mãe", "Pai", "Avó / avô", "Tio(a)", "Irmão(ã) maior", "Responsável legal", "Outro"
  ];

  /* ---------- Enfermagem ---------- */
  const TIPOS_ENFERMAGEM = [
    { id: "medicacao",     nome: "Medicação administrada", icone: "💊" },
    { id: "sinais",        nome: "Sinais vitais",          icone: "🌡️" },
    { id: "curativo",      nome: "Curativo / procedimento", icone: "🩹" },
    { id: "conforto",      nome: "Higiene e conforto",     icone: "🛁" },
    { id: "alimentacao",   nome: "Alimentação / hidratação", icone: "🍼" },
    { id: "observacao",    nome: "Observação de enfermagem", icone: "📝" }
  ];

  /* ---------- Avisos ---------- */
  const PRIORIDADES_AVISO = [
    { id: "info",       nome: "Informativo" },
    { id: "importante", nome: "Importante" },
    { id: "urgente",    nome: "Urgente" }
  ];

  const PUBLICOS_AVISO = [
    { id: "equipe", nome: "Somente equipe (mural interno)" },
    { id: "tv",     nome: "Somente painel da TV" },
    { id: "ambos",  nome: "Equipe e painel da TV" }
  ];

  /* ---------- Apoio ---------- */
  const porId = (lista, id) => lista.find(item => item.id === id) || null;
  const nomeDe = (lista, id) => (porId(lista, id) || { nome: id || "—" }).nome;

  return {
    TIPOS_SALA, STATUS_SALA, TIPOS_SETOR,
    CATEGORIAS_PROFISSIONAL, STATUS_PROFISSIONAL, TURNOS,
    ESTIMULOS_SENSORIAIS, TOLERANCIA_SENSORIAL,
    TIPOS_PEDAGOGIA, DISCIPLINAS,
    AREAS_DESENVOLVIMENTO, ESCALA_DESENVOLVIMENTO,
    TIPOS_APOIO_FAMILIAR, PARENTESCOS,
    TIPOS_ENFERMAGEM,
    PRIORIDADES_AVISO, PUBLICOS_AVISO,
    porId, nomeDe
  };
});
