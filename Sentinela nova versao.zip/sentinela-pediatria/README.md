# 🧸 Sentinela Pediatria 2.2

Sistema hospitalar pediátrico: recepção, triagem, pediatra, enfermagem, altas, farmácia,
painel de TV, **cuidado emocional**, **acolhimento e desenvolvimento infantil**,
**administração hospitalar** e a **Sentinela Intelligence** (conferência inteligente).

## Como rodar

```bash
npm install
npm start
# abre em http://localhost:3000
```

Variáveis de ambiente (opcionais, mas **obrigatórias em produção**):

| Variável         | Para quê                                                                   |
|------------------|----------------------------------------------------------------------------|
| `SESSION_SECRET` | Chave que assina as sessões. Na Vercel defina uma (texto longo e secreto). |
| `ADMIN_PASSWORD` | Senha do acesso administrativo rápido (padrão `123`, **troque**).          |
| `PORT`           | Porta do servidor (padrão 3000).                                           |

## Usuários de exemplo

| Usuário        | Senha      | Setor                        |
|----------------|------------|------------------------------|
| admin          | admin123   | Administrador                |
| atendimento    | 123        | Recepção                     |
| triagem        | 123        | Triagem                      |
| medico         | 123        | Pediatra                     |
| **enfermagem** | 123        | Enfermagem (novo)            |
| almoxarifado   | 123        | Farmácia                     |
| psicologia     | 123        | Psicologia                   |
| psiquiatria    | 123        | Psiquiatria infantil         |
| **pedagogia**  | 123        | Pedagogia hospitalar (novo)  |
| bemestar       | 123        | Equipe de bem-estar          |

> ⚠️ Troque todas as senhas antes de usar fora de testes (tela **Usuários**).

---

## O que há de novo na 2.2

### Nova navegação: menu lateral expansível

Em vez de dezenas de links no topo, o menu lateral agrupa as telas em **categorias que abrem e fecham**:

| Categoria              | Telas                                                                                   |
|------------------------|-----------------------------------------------------------------------------------------|
| Geral                  | Painel inicial, Indicadores                                                             |
| Atendimento            | Recepção, Triagem, Pediatra, Prescrições                                                |
| Saúde mental           | Psicologia, Psiquiatria, Acompanhamento emocional, Apoio aos familiares, Encaminhamentos |
| Infantil               | Espaços de acolhimento, Espaço sensorial, Atividades e agenda, Programação, Pedagogia, Desenvolvimento, Cantinho da criança |
| Enfermagem             | Cuidados de enfermagem                                                                  |
| Administração          | Usuários, Profissionais, Setores, Salas, Atividades e atendimentos, Relatórios          |
| Operacional            | Farmácia e almoxarifado, Altas                                                          |
| Comunicação            | Avisos e mural, Painel de chamadas (TV)                                                 |
| Sentinela Intelligence | Alertas, conferências, auditoria e permissões da IA                                     |

Cada pessoa vê **somente as telas do seu setor**. Recursos do menu:

- Categorias que abrem/fecham (a da tela atual abre sozinha; o menu **lembra** o que você deixou aberto).
- **Busca** de telas (tecla `/` foca a busca, `Enter` abre a primeira, `Esc` limpa).
- **Modo compacto** (só ícones) com o botão `‹`; clicar numa categoria expande o menu.
- **Selinhos** com pendências (aguardando triagem/pediatra/alta, pedidos de psicologia, pedagogia, alertas graves da IA…).
- Gaveta no celular; navegação por teclado e leitores de tela (`aria-expanded`, `aria-current`).
- **Painel inicial** para todos: saudação, avisos, o que está esperando e atalhos por categoria.

### 1. Espaço de acolhimento infantil

- **Espaços de acolhimento** (`acolhimento.html`): brinquedoteca, sala de recreação, área de
  convivência e espaço sensorial, com lotação em tempo real, entrada/saída de crianças e pedidos à equipe de bem-estar.
- **Espaço sensorial** (`sensorial.html`): registro de sessões (estímulos, humor antes/depois, reação),
  com confirmação obrigatória de liberação pela equipe de saúde.
- **Atividades educativas e recreativas**: catálogo ampliado (jogos educativos, oficina de leitura,
  brinquedo terapêutico, cinema) com categorias, e **Programação infantil** (`programacao.html`):
  atividades em grupo com sala, horário, vagas e inscrição. A sala é reservada automaticamente e,
  ao concluir, a participação de cada criança entra na agenda dela.

### 2. Saúde mental

- Consultório de psicologia e atendimento psiquiátrico (já existentes) agora no menu **Saúde mental**.
- **Acompanhamento emocional** (`acompanhamento.html`): linha do tempo com humor, dor, sessões,
  espaço sensorial e atividades, gráfico de humor e tendência. **O texto das sessões e avaliações só
  aparece para psicologia e psiquiatria**; pediatra e enfermagem veem a evolução sem o conteúdo sigiloso.
- **Apoio aos familiares** (`familia.html`): registro de atendimentos a pais/responsáveis (sigiloso).
- **Encaminhamentos entre profissionais** (`encaminhamentos.html`): psicologia, psiquiatria,
  pedagogia e equipe de bem-estar, com urgência, acompanhamento e conclusão automática quando a criança é atendida.
  O pediatra também encaminha direto da consulta.

### 3. Desenvolvimento e educação

- **Pedagogia hospitalar** (`pedagogia.html`): atividades escolares, contato com a escola, preparo
  para a volta às aulas; lembra escola e série da criança.
- **Acompanhamento do desenvolvimento** (`desenvolvimento.html`): 5 áreas (motor, linguagem,
  cognitivo, socioemocional, autonomia) em escala de 1 a 4, evolução ao longo do tempo e
  encaminhamento automático quando alguma área pede atenção.

### 4. Administração hospitalar

- **Profissionais** (CRM/COREN/CRP…, validação de registro duplicado), **Setores**, **Salas**
  (capacidade, situação, **reservas com detecção de conflito**).
- **Atividades e atendimentos**: tudo o que aconteceu, com filtros e exportação para planilha (CSV).
- **Relatórios** por período: números por categoria, profissional, dia, uso das salas, saúde mental,
  infantil, encaminhamentos, farmácia e IA; exportação CSV e impressão/PDF.
- **Avisos e mural**: mural interno da equipe e avisos na faixa do **painel da TV**
  (só recepção e administração publicam na TV, que é pública).

### 5. Enfermagem

- **Cuidados de enfermagem** (`enfermagem.html`): medicação administrada, sinais vitais
  (avisa se indicam risco), curativos, conforto, alimentação e observações. Mostra a prescrição
  atual da criança e confere a administração com a IA.

---

## 🛡️ Sentinela Intelligence

Assistente de **conferência** integrado ao sistema, com backend próprio em `backend/ia/`.
Ela **apoia** a decisão do profissional e **nunca decide sozinha**.

> **Importante:** o motor atual é **baseado em regras claras e explicáveis** (determinístico),
> não um modelo de linguagem. Isso é proposital para uso clínico: cada alerta tem código, motivo e
> gravidade, e a lista completa de regras aparece na aba **Como funciona** da tela da IA.
> O motor pode ser ampliado com novas regras (ver abaixo) ou com um modelo de linguagem no futuro.

| Recurso                  | O que faz                                                                                       |
|--------------------------|--------------------------------------------------------------------------------------------------|
| **Prescrição**           | Ao prescrever: alergia da triagem, dose por kg (faixa e máximo diário), idade/peso mínimos, medicamento repetido ou da mesma classe, anti-inflamatório em dengue, antibiótico em diagnóstico viral, falta de estoque, mg x mL que não conferem |
| **Administração**        | Enfermagem: medicamento fora da prescrição, dose diferente, intervalo curto, excesso no dia, alergia |
| **Dados do paciente**    | Nascimento inválido, CPF inválido/repetido, cadastro duplicado, telefone incompleto, peso incomum para a idade, risco subclassificado |
| **Painel de alertas**    | Visão geral: espera acima do alvo, encaminhamento urgente parado, dor forte, risco psiquiátrico, estoque zerado/baixo |
| **Auditoria**            | Trilha de **quem fez o quê e quando** (login, cadastros, consultas, leitura de dados sensíveis)  |
| **Permissões**           | O administrador define o que cada profissional pode usar da IA (padrão por setor)                |

**Como funciona um alerta grave:** a prescrição (ou administração) **é barrada** e abre uma janela com os alertas.
O profissional pode **voltar e revisar** ou **manter com justificativa escrita**. A justificativa fica gravada
no registro e na auditoria, e aparece no painel como "profissional ciente". Alertas de atenção/informativos apenas avisam.

**Privacidade:** a auditoria guarda a ação e a criança envolvida, **não** o conteúdo clínico.
Acessos de leitura a dados sensíveis (sessões, avaliações, acompanhamento) também são registrados.

### Como acrescentar uma regra à IA

1. Em `backend/ia/catalogo.js`, adicione a regra em `REGRAS` (código, área, gravidade, título).
2. Use `alerta("MEU_CODIGO", "explicação")` na função certa: `prescricao.js`, `medicacao.js` ou `paciente.js`.
3. Ela já aparece sozinha na tela da IA, nos alertas e na auditoria.

---

## Segurança (novo)

- **Toda rota exige login** (token assinado, validade de 12 h), exceto `/login`, `/admin/acesso` e `/tv-dados`.
- Rotas de administração (`/usuarios`, `/profissionais`, `/setores`, `/salas`, `/relatorios`, `/controle`,
  permissões da IA) são **só do administrador**. O prontuário de saúde mental (sessões, avaliações, apoio a familiares)
  é restrito a psicologia e psiquiatria, e **nem o administrador o lê** (ele vê apenas números nos relatórios).
- **5 senhas erradas em 10 minutos** bloqueiam a conta por um tempo.
- Senhas guardadas com hash. O painel da TV só recebe título e texto dos avisos (nunca o autor).

## Estrutura

```
backend/
  server.js           login, recepção, triagem, consulta, alta, farmácia, TV
  auth.js             sessão assinada (token) e proteção das rotas
  apoio.js            funções compartilhadas (pacientes, encaminhamentos, reservas)
  rotas-bemestar.js   psicologia, psiquiatria, humor, atividades, encaminhamentos
  rotas-infantil.js   espaço sensorial, pedagogia, desenvolvimento, programação
  rotas-saude.js      apoio a familiares, acompanhamento emocional, enfermagem
  rotas-gestao.js     profissionais, setores, salas, reservas, avisos, controle, relatórios
  ia/                 Sentinela Intelligence
    index.js            rotas /ia/* e funções usadas pelo servidor
    catalogo.js         catálogo de regras e vocabulário
    prescricao.js       conferência de prescrições
    medicacao.js        conferência da administração (enfermagem)
    paciente.js         conferência de cadastro/triagem e painel de alertas
    permissoes.js       o que cada profissional pode usar da IA
    auditoria.js        trilha de auditoria
  banco.js            leitura/gravação do db.json, senhas e dados iniciais
  util.js             funções pequenas de apoio
  db.json             dados

frontend/
  index.html          login
  inicio.html         painel inicial
  admin.html          indicadores do administrador
  ... uma página por tela do menu (veja a tabela acima)
  tv.html             painel de chamada (com faixa de avisos)
  css/style.css       visual
  js/app.js           menu lateral, permissões e funções comuns
  js/pediatria.js     regras clínicas (risco, doses)
  js/bemestar.js      escalas e catálogos do cuidado emocional
  js/hospital.js      listas de salas, profissionais, desenvolvimento, enfermagem...
```

## Como adicionar uma tela nova ao menu

1. Crie o `.html` (copie uma tela existente; ela começa com `guard("nome")`).
2. Em `frontend/js/app.js`, acrescente uma linha em **`MODULOS`** (escolha o `grupo` entre os de `GRUPOS`).
3. Coloque o nome da tela em **`ACESSO`**, nos setores que podem vê-la.

O menu, a busca, o painel inicial e os atalhos se ajustam sozinhos.
Para um **novo setor (perfil de usuário)**: acrescente em `SETORES` e `ACESSO` (em `app.js`) e em
`SETORES` no `backend/server.js`.

## Para editar as listas

- Cuidado emocional (atividades, sinais, técnicas, escalas): `frontend/js/bemestar.js`.
- Salas, profissionais, desenvolvimento, enfermagem, avisos: `frontend/js/hospital.js`.
- Doses e formulário de medicamentos: `frontend/js/pediatria.js` (a IA usa essas mesmas faixas).

## Avisos importantes

- Conteúdo clínico (classificação, doses, sinais, condutas, regras da IA) é **apoio/demonstração**
  e deve ser **validado pelos protocolos do hospital** antes de uso real.
- **Antes de usar com dados reais:** defina `SESSION_SECRET` e `ADMIN_PASSWORD`, troque todas as senhas,
  use HTTPS e avalie a adequação à **LGPD** (dados de saúde de crianças são dados sensíveis).
- O controle de acesso por setor existe nas telas e nas rotas mais sensíveis. Para uso real, revise
  rota a rota quais perfis podem ler/gravar cada coisa (há o ajudante `exigirTipo` em `auth.js`).
- Na Vercel o `db.json` fica em `/tmp` e é apagado de tempos em tempos (e as sessões deixam de valer
  se `SESSION_SECRET` não estiver definido). Para uso real, use um banco de dados.
